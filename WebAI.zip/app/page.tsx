'use client';

import Header from '../components/Header';
import Footer from '../components/Footer';
import Link from 'next/link';

export default function Home() {
  return (
    <div className="min-h-screen bg-white">
      <Header />

      {/* Hero Section */}
      <section className="relative min-h-screen flex items-center overflow-hidden">
        <div 
          className="absolute inset-0 bg-cover bg-center bg-no-repeat transform scale-105"
          style={{
            backgroundImage: `url('https://readdy.ai/api/search-image?query=Beautiful%20modern%20school%20campus%20with%20green%20lawns%2C%20academic%20buildings%2C%20students%20walking%20with%20backpacks%20in%20sunny%20daylight%2C%20clean%20educational%20environment%20with%20trees%20and%20pathways%2C%20inspiring%20learning%20atmosphere%20with%20contemporary%20architecture%20and%20blue%20sky&width=1920&height=1080&seq=hero-school&orientation=landscape')`
          }}
        ></div>
        <div className="absolute inset-0 bg-gradient-to-br from-blue-900/80 via-blue-800/70 to-purple-900/60"></div>
        <div className="absolute inset-0 bg-black/20"></div>

        <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 w-full">
          <div className="max-w-4xl transform perspective-1000">
            <div className="bg-gradient-to-r from-white/10 to-white/5 backdrop-blur-lg rounded-3xl p-8 md:p-12 shadow-2xl border border-white/20 transform hover:scale-105 transition-all duration-700 hover:shadow-3xl">
              <h1 className="text-4xl md:text-6xl font-bold text-white mb-6 leading-tight drop-shadow-2xl transform hover:translate-y-[-2px] transition-transform duration-300">
                Welcome to <span className="bg-gradient-to-r from-yellow-300 via-blue-300 to-purple-300 bg-clip-text text-transparent">Vivekananda</span> International School
              </h1>
              <p className="text-xl md:text-2xl text-blue-100 mb-8 leading-relaxed drop-shadow-lg transform hover:translate-y-[-1px] transition-transform duration-300">
                Nurturing young minds with excellence in education, character development, and holistic growth since 1985.
              </p>
              <div className="flex flex-col sm:flex-row gap-6">
                <div className="group perspective-1000">
                  <Link href="/admission/online-learning" className="block bg-gradient-to-r from-blue-600 to-blue-700 hover:from-blue-500 hover:to-blue-600 text-white px-10 py-5 rounded-2xl font-semibold text-lg transition-all duration-500 text-center cursor-pointer whitespace-nowrap shadow-2xl hover:shadow-blue-500/25 transform group-hover:scale-110 group-hover:translate-y-[-4px] group-hover:rotate-1 border border-blue-400/30">
                    <span className="drop-shadow-lg">Apply Now</span>
                    <div className="absolute inset-0 bg-gradient-to-r from-white/20 to-transparent rounded-2xl opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
                  </Link>
                </div>
                <div className="group perspective-1000">
                  <Link href="/about/welcome" className="block bg-white/10 backdrop-blur-md hover:bg-white/20 text-white px-10 py-5 rounded-2xl font-semibold text-lg transition-all duration-500 text-center border border-white/30 cursor-pointer whitespace-nowrap shadow-2xl hover:shadow-white/10 transform group-hover:scale-110 group-hover:translate-y-[-4px] group-hover:rotate-[-1deg]">
                    <span className="drop-shadow-lg">Learn More</span>
                    <div className="absolute inset-0 bg-gradient-to-r from-white/10 to-transparent rounded-2xl opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
                  </Link>
                </div>
              </div>
            </div>
            
            {/* Floating Elements */}
            <div className="absolute -top-4 -right-4 w-20 h-20 bg-gradient-to-br from-yellow-400 to-orange-500 rounded-full opacity-80 blur-sm animate-pulse"></div>
            <div className="absolute -bottom-6 -left-6 w-16 h-16 bg-gradient-to-br from-purple-400 to-pink-500 rounded-full opacity-70 blur-sm animate-pulse delay-1000"></div>
            <div className="absolute top-1/2 -right-8 w-12 h-12 bg-gradient-to-br from-blue-400 to-cyan-500 rounded-full opacity-60 blur-sm animate-bounce"></div>
          </div>
        </div>

        {/* Parallax Elements */}
        <div className="absolute top-20 left-10 w-32 h-32 bg-gradient-to-br from-blue-400/20 to-purple-500/20 rounded-full blur-2xl animate-float"></div>
        <div className="absolute bottom-32 right-16 w-24 h-24 bg-gradient-to-br from-yellow-400/30 to-orange-500/30 rounded-full blur-xl animate-float-delayed"></div>
        <div className="absolute top-1/3 right-1/4 w-16 h-16 bg-gradient-to-br from-pink-400/25 to-red-500/25 rounded-full blur-lg animate-pulse"></div>
      </section>

      {/* Features Section */}
      <section className="py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
              Why Choose Vivekananda International School?
            </h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              We provide world-class education with a focus on academic excellence, character building, and comprehensive development.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            <div className="bg-white rounded-2xl p-8 shadow-lg hover:shadow-xl transition-shadow duration-300">
              <div className="w-16 h-16 bg-blue-100 rounded-xl flex items-center justify-center mb-6">
                <i className="ri-book-open-line text-blue-600 text-2xl w-8 h-8 flex items-center justify-center"></i>
              </div>
              <h3 className="text-xl font-semibold text-gray-900 mb-4">Excellence in Academics</h3>
              <p className="text-gray-600">
                Comprehensive curriculum designed to challenge and inspire students with innovative teaching methodologies and modern learning resources.
              </p>
            </div>

            <div className="bg-white rounded-2xl p-8 shadow-lg hover:shadow-xl transition-shadow duration-300">
              <div className="w-16 h-16 bg-green-100 rounded-xl flex items-center justify-center mb-6">
                <i className="ri-team-line text-green-600 text-2xl w-8 h-8 flex items-center justify-center"></i>
              </div>
              <h3 className="text-xl font-semibold text-gray-900 mb-4">Experienced Faculty</h3>
              <p className="text-gray-600">
                Dedicated and qualified teachers committed to nurturing each student's potential and providing personalized attention to their growth.
              </p>
            </div>

            <div className="bg-white rounded-2xl p-8 shadow-lg hover:shadow-xl transition-shadow duration-300">
              <div className="w-16 h-16 bg-purple-100 rounded-xl flex items-center justify-center mb-6">
                <i className="ri-trophy-line text-purple-600 text-2xl w-8 h-8 flex items-center justify-center"></i>
              </div>
              <h3 className="text-xl font-semibold text-gray-900 mb-4">Holistic Development</h3>
              <p className="text-gray-600">
                Focus on overall personality development through sports, arts, community service, and leadership opportunities for well-rounded growth.
              </p>
            </div>

            <div className="bg-white rounded-2xl p-8 shadow-lg hover:shadow-xl transition-shadow duration-300">
              <div className="w-16 h-16 bg-red-100 rounded-xl flex items-center justify-center mb-6">
                <i className="ri-computer-line text-red-600 text-2xl w-8 h-8 flex items-center justify-center"></i>
              </div>
              <h3 className="text-xl font-semibold text-gray-900 mb-4">Modern Infrastructure</h3>
              <p className="text-gray-600">
                State-of-the-art facilities including smart classrooms, science labs, libraries, and technology centers for enhanced learning experience.
              </p>
            </div>

            <div className="bg-white rounded-2xl p-8 shadow-lg hover:shadow-xl transition-shadow duration-300">
              <div className="w-16 h-16 bg-yellow-100 rounded-xl flex items-center justify-center mb-6">
                <i className="ri-global-line text-yellow-600 text-2xl w-8 h-8 flex items-center justify-center"></i>
              </div>
              <h3 className="text-xl font-semibold text-gray-900 mb-4">Global Perspective</h3>
              <p className="text-gray-600">
                International curriculum and exchange programs that prepare students for global citizenship and future challenges.
              </p>
            </div>

            <div className="bg-white rounded-2xl p-8 shadow-lg hover:shadow-xl transition-shadow duration-300">
              <div className="w-16 h-16 bg-indigo-100 rounded-xl flex items-center justify-center mb-6">
                <i className="ri-heart-line text-indigo-600 text-2xl w-8 h-8 flex items-center justify-center"></i>
              </div>
              <h3 className="text-xl font-semibold text-gray-900 mb-4">Values & Ethics</h3>
              <p className="text-gray-600">
                Strong emphasis on moral values, ethics, and character development to create responsible and compassionate global citizens.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Statistics Section */}
      <section className="py-20 bg-blue-900">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
            <div className="text-center">
              <div className="text-4xl md:text-5xl font-bold text-white mb-2">39+</div>
              <div className="text-blue-200 text-lg">Years of Excellence</div>
            </div>
            <div className="text-center">
              <div className="text-4xl md:text-5xl font-bold text-white mb-2">2500+</div>
              <div className="text-blue-200 text-lg">Students</div>
            </div>
            <div className="text-center">
              <div className="text-4xl md:text-5xl font-bold text-white mb-2">150+</div>
              <div className="text-blue-200 text-lg">Faculty Members</div>
            </div>
            <div className="text-center">
              <div className="text-4xl md:text-5xl font-bold text-white mb-2">98%</div>
              <div className="text-blue-200 text-lg">Success Rate</div>
            </div>
          </div>
        </div>
      </section>

      {/* News & Events Section */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
              Latest News & Events
            </h2>
            <p className="text-xl text-gray-600">
              Stay updated with the latest happenings at our school
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            <div className="bg-white rounded-2xl shadow-lg overflow-hidden hover:shadow-xl transition-shadow duration-300">
              <img 
                src="https://readdy.ai/api/search-image?query=School%20science%20fair%20with%20students%20presenting%20projects%2C%20colorful%20displays%20and%20experiments%2C%20bright%20classroom%20setting%20with%20educational%20posters%2C%20young%20students%20in%20school%20uniforms%20proudly%20showing%20their%20work&width=400&height=250&seq=news1&orientation=landscape"
                alt="Science Fair"
                className="w-full h-48 object-cover object-top"
              />
              <div className="p-6">
                <div className="text-blue-600 text-sm font-medium mb-2">March 15, 2024</div>
                <h3 className="text-xl font-semibold text-gray-900 mb-3">Annual Science Fair 2024</h3>
                <p className="text-gray-600 mb-4">
                  Students showcase innovative projects and experiments in our annual science exhibition.
                </p>
                <Link href="#" className="text-blue-600 hover:text-blue-700 font-medium cursor-pointer">
                  Read More →
                </Link>
              </div>
            </div>

            <div className="bg-white rounded-2xl shadow-lg overflow-hidden hover:shadow-xl transition-shadow duration-300">
              <img 
                src="https://readdy.ai/api/search-image?query=School%20sports%20day%20with%20students%20running%20on%20track%2C%20athletic%20competition%2C%20stadium%20setting%20with%20cheering%20crowds%2C%20colorful%20sports%20uniforms%20and%20banners%2C%20sunny%20outdoor%20event&width=400&height=250&seq=news2&orientation=landscape"
                alt="Sports Day"
                className="w-full h-48 object-cover object-top"
              />
              <div className="p-6">
                <div className="text-blue-600 text-sm font-medium mb-2">March 10, 2024</div>
                <h3 className="text-xl font-semibold text-gray-900 mb-3">Inter-House Sports Championship</h3>
                <p className="text-gray-600 mb-4">
                  Exciting athletic competitions bringing out the best in our student athletes.
                </p>
                <Link href="#" className="text-blue-600 hover:text-blue-700 font-medium cursor-pointer">
                  Read More →
                </Link>
              </div>
            </div>

            <div className="bg-white rounded-2xl shadow-lg overflow-hidden hover:shadow-xl transition-shadow duration-300">
              <img 
                src="https://readdy.ai/api/search-image?query=School%20cultural%20program%20with%20students%20performing%20on%20stage%2C%20colorful%20costumes%20and%20decorations%2C%20auditorium%20setting%20with%20stage%20lights%2C%20dance%20and%20music%20performance%2C%20proud%20families%20watching&width=400&height=250&seq=news3&orientation=landscape"
                alt="Cultural Program"
                className="w-full h-48 object-cover object-top"
              />
              <div className="p-6">
                <div className="text-blue-600 text-sm font-medium mb-2">March 5, 2024</div>
                <h3 className="text-xl font-semibold text-gray-900 mb-3">Cultural Festival Celebration</h3>
                <p className="text-gray-600 mb-4">
                  A vibrant celebration of arts, culture, and traditions with spectacular performances.
                </p>
                <Link href="#" className="text-blue-600 hover:text-blue-700 font-medium cursor-pointer">
                  Read More →
                </Link>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-gradient-to-r from-blue-600 to-blue-800">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl md:text-4xl font-bold text-white mb-6">
            Ready to Join Our School Community?
          </h2>
          <p className="text-xl text-blue-100 mb-8 max-w-2xl mx-auto">
            Take the first step towards your child's bright future. Apply now or schedule a campus visit.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link href="/admission/online-learning" className="bg-white hover:bg-gray-100 text-blue-600 px-8 py-4 rounded-lg font-semibold text-lg transition-all duration-300 cursor-pointer whitespace-nowrap">
              Start Application
            </Link>
            <Link href="/contact" className="bg-blue-500 hover:bg-blue-400 text-white px-8 py-4 rounded-lg font-semibold text-lg transition-all duration-300 cursor-pointer whitespace-nowrap">
              Schedule Visit
            </Link>
          </div>
        </div>
      </section>

      <Footer />
    </div>
  );
}
