
'use client';

import Header from '../../../components/Header';
import Footer from '../../../components/Footer';

export default function Welcome() {
  return (
    <div className="min-h-screen bg-white">
      <Header />

      {/* Hero Section */}
      <section className="relative py-24 overflow-hidden">
        <div 
          className="absolute inset-0 bg-cover bg-center bg-no-repeat"
          style={{
            backgroundImage: `url('https://readdy.ai/api/search-image?query=Beautiful%20school%20entrance%20with%20welcoming%20gates%2C%20lush%20green%20gardens%2C%20modern%20architecture%2C%20students%20walking%20happily%2C%20bright%20sunlight%20and%20peaceful%20academic%20atmosphere%2C%20inspiring%20educational%20environment&width=1920&height=800&seq=welcome-hero&orientation=landscape')`
          }}
        ></div>
        <div className="absolute inset-0 bg-gradient-to-br from-blue-900/80 via-blue-800/70 to-purple-900/60"></div>
        
        <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center transform perspective-1000">
            <div className="bg-gradient-to-r from-white/15 to-white/10 backdrop-blur-lg rounded-3xl p-8 md:p-12 shadow-2xl border border-white/20 transform hover:scale-105 transition-all duration-700">
              <h1 className="text-4xl md:text-6xl font-bold text-white mb-6 leading-tight drop-shadow-2xl">
                Welcome to <span className="bg-gradient-to-r from-yellow-300 via-blue-300 to-purple-300 bg-clip-text text-transparent">Vivekananda</span>
              </h1>
              <p className="text-xl md:text-2xl text-blue-100 mb-8 leading-relaxed drop-shadow-lg max-w-3xl mx-auto">
                Where excellence meets tradition, and every student's potential is nurtured to create tomorrow's leaders.
              </p>
            </div>
          </div>
        </div>

        {/* Floating Elements */}
        <div className="absolute top-20 left-10 w-32 h-32 bg-gradient-to-br from-blue-400/20 to-purple-500/20 rounded-full blur-2xl animate-float"></div>
        <div className="absolute bottom-32 right-16 w-24 h-24 bg-gradient-to-br from-yellow-400/30 to-orange-500/30 rounded-full blur-xl animate-float-delayed"></div>
      </section>

      {/* Welcome Message */}
      <section className="py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="max-w-4xl mx-auto">
            <div className="bg-white rounded-3xl shadow-2xl p-8 md:p-12 transform hover:shadow-3xl transition-all duration-500">
              <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-8 text-center">
                A Message of Welcome
              </h2>
              
              <div className="prose prose-lg max-w-none text-gray-700 leading-relaxed space-y-6">
                <p className="text-xl text-gray-800 font-medium">
                  Dear Students, Parents, and Visitors,
                </p>
                
                <p>
                  It is with great pride and joy that I welcome you to Vivekananda International School, a distinguished institution that has been shaping young minds and nurturing future leaders for over three decades. Since our establishment in 1985, we have remained committed to providing world-class education that combines academic excellence with character development.
                </p>
                
                <p>
                  Our school stands as a beacon of educational innovation, where traditional values meet modern pedagogical approaches. We believe that every child is unique and possesses inherent potential that, when properly nurtured, can lead to extraordinary achievements. Our dedicated faculty, state-of-the-art facilities, and comprehensive curriculum are all designed to unlock this potential in every student who walks through our doors.
                </p>
                
                <p>
                  At Vivekananda International School, we don't just educate; we inspire. We don't just teach subjects; we cultivate minds. We don't just prepare students for examinations; we prepare them for life. Our holistic approach ensures that our students develop not only intellectual capabilities but also emotional intelligence, social responsibility, and ethical values.
                </p>
                
                <p>
                  We are proud of our diverse community that includes students from various cultural backgrounds, creating a rich tapestry of experiences and perspectives. This diversity enhances our learning environment and prepares our students to thrive in an increasingly interconnected world.
                </p>
                
                <p className="text-xl text-gray-800 font-medium">
                  Whether you are a prospective student, a parent considering our school for your child, or a visitor exploring our community, we extend our warmest welcome. We invite you to discover the Vivekananda difference – where education transcends the ordinary and every student's journey is extraordinary.
                </p>
                
                <p className="text-lg text-blue-600 font-semibold">
                  Welcome to our family. Welcome to excellence. Welcome to Vivekananda International School.
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Features Grid */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
              What Makes Us Special
            </h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Discover the unique elements that set Vivekananda International School apart in the world of education.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            <div className="bg-gradient-to-br from-blue-50 to-purple-50 rounded-3xl p-8 shadow-lg hover:shadow-xl transition-all duration-300 transform hover:scale-105">
              <div className="w-16 h-16 bg-blue-600 rounded-2xl flex items-center justify-center mb-6 shadow-lg">
                <i className="ri-award-line text-white text-2xl w-8 h-8 flex items-center justify-center"></i>
              </div>
              <h3 className="text-xl font-semibold text-gray-900 mb-4">Academic Excellence</h3>
              <p className="text-gray-700">
                Consistent outstanding results with 98% success rate in board examinations and university admissions.
              </p>
            </div>

            <div className="bg-gradient-to-br from-green-50 to-blue-50 rounded-3xl p-8 shadow-lg hover:shadow-xl transition-all duration-300 transform hover:scale-105">
              <div className="w-16 h-16 bg-green-600 rounded-2xl flex items-center justify-center mb-6 shadow-lg">
                <i className="ri-global-line text-white text-2xl w-8 h-8 flex items-center justify-center"></i>
              </div>
              <h3 className="text-xl font-semibold text-gray-900 mb-4">Global Perspective</h3>
              <p className="text-gray-700">
                International curriculum and exchange programs preparing students for global citizenship.
              </p>
            </div>

            <div className="bg-gradient-to-br from-purple-50 to-pink-50 rounded-3xl p-8 shadow-lg hover:shadow-xl transition-all duration-300 transform hover:scale-105">
              <div className="w-16 h-16 bg-purple-600 rounded-2xl flex items-center justify-center mb-6 shadow-lg">
                <i className="ri-heart-3-line text-white text-2xl w-8 h-8 flex items-center justify-center"></i>
              </div>
              <h3 className="text-xl font-semibold text-gray-900 mb-4">Character Building</h3>
              <p className="text-gray-700">
                Strong emphasis on values, ethics, and moral development alongside academic growth.
              </p>
            </div>

            <div className="bg-gradient-to-br from-orange-50 to-yellow-50 rounded-3xl p-8 shadow-lg hover:shadow-xl transition-all duration-300 transform hover:scale-105">
              <div className="w-16 h-16 bg-orange-600 rounded-2xl flex items-center justify-center mb-6 shadow-lg">
                <i className="ri-team-line text-white text-2xl w-8 h-8 flex items-center justify-center"></i>
              </div>
              <h3 className="text-xl font-semibold text-gray-900 mb-4">Expert Faculty</h3>
              <p className="text-gray-700">
                150+ highly qualified and experienced teachers committed to student success.
              </p>
            </div>

            <div className="bg-gradient-to-br from-red-50 to-orange-50 rounded-3xl p-8 shadow-lg hover:shadow-xl transition-all duration-300 transform hover:scale-105">
              <div className="w-16 h-16 bg-red-600 rounded-2xl flex items-center justify-center mb-6 shadow-lg">
                <i className="ri-building-line text-white text-2xl w-8 h-8 flex items-center justify-center"></i>
              </div>
              <h3 className="text-xl font-semibold text-gray-900 mb-4">Modern Infrastructure</h3>
              <p className="text-gray-700">
                State-of-the-art facilities including smart classrooms, labs, and sports complexes.
              </p>
            </div>

            <div className="bg-gradient-to-br from-indigo-50 to-blue-50 rounded-3xl p-8 shadow-lg hover:shadow-xl transition-all duration-300 transform hover:scale-105">
              <div className="w-16 h-16 bg-indigo-600 rounded-2xl flex items-center justify-center mb-6 shadow-lg">
                <i className="ri-star-line text-white text-2xl w-8 h-8 flex items-center justify-center"></i>
              </div>
              <h3 className="text-xl font-semibold text-gray-900 mb-4">Holistic Development</h3>
              <p className="text-gray-700">
                Comprehensive programs in sports, arts, leadership, and community service.
              </p>
            </div>
          </div>
        </div>
      </section>

      <Footer />
    </div>
  );
}
