
'use client';

import Header from '../../../components/Header';
import Footer from '../../../components/Footer';

export default function PrincipalMessage() {
  return (
    <div className="min-h-screen bg-white">
      <Header />

      {/* Hero Section */}
      <section className="relative py-24 overflow-hidden">
        <div 
          className="absolute inset-0 bg-cover bg-center bg-no-repeat"
          style={{
            backgroundImage: `url('https://readdy.ai/api/search-image?query=Professional%20female%20principal%20in%20office%20setting%2C%20warm%20and%20welcoming%20atmosphere%2C%20educational%20certificates%20on%20wall%2C%20bookshelf%20background%2C%20natural%20lighting%2C%20inspirational%20and%20leadership-focused%20environment&width=1920&height=800&seq=principal-hero&orientation=landscape')`
          }}
        ></div>
        <div className="absolute inset-0 bg-gradient-to-br from-blue-900/85 via-blue-800/75 to-purple-900/70"></div>
        
        <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center transform perspective-1000">
            <div className="bg-gradient-to-r from-white/15 to-white/10 backdrop-blur-lg rounded-3xl p-8 md:p-12 shadow-2xl border border-white/20 transform hover:scale-105 transition-all duration-700">
              <h1 className="text-4xl md:text-6xl font-bold text-white mb-6 leading-tight drop-shadow-2xl">
                Principal's <span className="bg-gradient-to-r from-yellow-300 via-blue-300 to-purple-300 bg-clip-text text-transparent">Message</span>
              </h1>
              <p className="text-xl md:text-2xl text-blue-100 mb-8 leading-relaxed drop-shadow-lg max-w-3xl mx-auto">
                A personal message from our school's leadership about our vision and commitment to excellence.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Principal's Message */}
      <section className="py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-12">
            {/* Principal's Photo */}
            <div className="lg:col-span-1">
              <div className="bg-white rounded-3xl shadow-2xl p-8 text-center transform hover:shadow-3xl transition-all duration-500">
                <div className="w-48 h-48 mx-auto mb-6 rounded-full overflow-hidden shadow-xl">
                  <img 
                    src="https://readdy.ai/api/search-image?query=Professional%20female%20school%20principal%20portrait%2C%20confident%20and%20warm%20smile%2C%20business%20attire%2C%20educational%20background%2C%20inspiring%20leadership%20appearance%2C%20formal%20headshot%20for%20school%20website&width=300&height=300&seq=principal-photo&orientation=squarish"
                    alt="Principal Dr. Sarah Mitchell"
                    className="w-full h-full object-cover object-top"
                  />
                </div>
                <h3 className="text-2xl font-bold text-gray-900 mb-2">Dr. Sarah Mitchell</h3>
                <p className="text-blue-600 font-semibold mb-4">Principal</p>
                <div className="space-y-2 text-sm text-gray-600">
                  <p>M.Ed., Ph.D. in Educational Leadership</p>
                  <p>20+ Years in Education</p>
                  <p>Former UNESCO Education Consultant</p>
                </div>
              </div>
            </div>

            {/* Message Content */}
            <div className="lg:col-span-2">
              <div className="bg-white rounded-3xl shadow-2xl p-8 md:p-12 transform hover:shadow-3xl transition-all duration-500">
                <h2 className="text-3xl font-bold text-gray-900 mb-8">
                  A Message from Our Principal
                </h2>
                
                <div className="prose prose-lg max-w-none text-gray-700 leading-relaxed space-y-6">
                  <p className="text-xl text-gray-800 font-medium">
                    Dear Vivekananda International School Community,
                  </p>
                  
                  <p>
                    As I reflect on my journey as Principal of this remarkable institution, I am filled with immense pride and gratitude. For the past eight years, I have had the privilege of leading a school that stands as a testament to educational excellence, innovation, and unwavering commitment to student success.
                  </p>
                  
                  <p>
                    Education is not merely about imparting knowledge; it is about igniting curiosity, fostering creativity, and developing critical thinking skills that will serve our students throughout their lives. At Vivekananda International School, we believe that every child possesses unique talents and capabilities that, when nurtured with care and dedication, can lead to extraordinary achievements.
                  </p>
                  
                  <p>
                    Our philosophy centers on holistic development – we strive to educate not just the mind, but also the heart and soul. In today's rapidly evolving world, we prepare our students to be adaptable, resilient, and compassionate global citizens who can navigate challenges with confidence and contribute meaningfully to society.
                  </p>
                  
                  <blockquote className="border-l-4 border-blue-500 pl-6 italic text-gray-800 bg-blue-50 p-6 rounded-r-2xl">
                    "Our mission is to create an environment where students feel safe to explore, fail, learn, and succeed. We celebrate diversity, encourage innovation, and foster a culture of mutual respect and understanding."
                  </blockquote>
                  
                  <p>
                    I am particularly proud of our dedicated faculty who go above and beyond to ensure that each student receives personalized attention and support. Their passion for teaching and commitment to student welfare is the cornerstone of our success. Together, we have created a learning environment that challenges students academically while supporting their emotional and social growth.
                  </p>
                  
                  <p>
                    To our students, I encourage you to embrace every opportunity, ask questions, think critically, and never stop learning. Remember that your education is not just about grades – it's about becoming the best version of yourself and making a positive impact on the world around you.
                  </p>
                  
                  <p>
                    To our parents, thank you for entrusting us with your most precious gifts – your children. Your partnership and support are invaluable in our shared mission of nurturing young minds and shaping future leaders.
                  </p>
                  
                  <p className="text-xl text-blue-600 font-semibold">
                    Together, we will continue to uphold the values and traditions that make Vivekananda International School a beacon of educational excellence.
                  </p>
                  
                  <div className="mt-8 pt-6 border-t border-gray-200">
                    <p className="font-semibold text-gray-900">Warm regards,</p>
                    <p className="text-2xl font-bold text-blue-600 mt-2">Dr. Sarah Mitchell</p>
                    <p className="text-gray-600">Principal, Vivekananda International School</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Achievements Section */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
              Leadership Achievements
            </h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Under Dr. Mitchell's leadership, our school has achieved remarkable milestones.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            <div className="text-center bg-gradient-to-br from-blue-50 to-purple-50 rounded-3xl p-8 shadow-lg hover:shadow-xl transition-all duration-300">
              <div className="w-16 h-16 bg-blue-600 rounded-2xl flex items-center justify-center mx-auto mb-4 shadow-lg">
                <i className="ri-award-line text-white text-2xl w-8 h-8 flex items-center justify-center"></i>
              </div>
              <div className="text-3xl font-bold text-blue-600 mb-2">5</div>
              <div className="text-gray-700 font-medium">National Awards</div>
            </div>

            <div className="text-center bg-gradient-to-br from-green-50 to-blue-50 rounded-3xl p-8 shadow-lg hover:shadow-xl transition-all duration-300">
              <div className="w-16 h-16 bg-green-600 rounded-2xl flex items-center justify-center mx-auto mb-4 shadow-lg">
                <i className="ri-trophy-line text-white text-2xl w-8 h-8 flex items-center justify-center"></i>
              </div>
              <div className="text-3xl font-bold text-green-600 mb-2">98%</div>
              <div className="text-gray-700 font-medium">Success Rate</div>
            </div>

            <div className="text-center bg-gradient-to-br from-purple-50 to-pink-50 rounded-3xl p-8 shadow-lg hover:shadow-xl transition-all duration-300">
              <div className="w-16 h-16 bg-purple-600 rounded-2xl flex items-center justify-center mx-auto mb-4 shadow-lg">
                <i className="ri-graduation-cap-line text-white text-2xl w-8 h-8 flex items-center justify-center"></i>
              </div>
              <div className="text-3xl font-bold text-purple-600 mb-2">2500+</div>
              <div className="text-gray-700 font-medium">Students Graduated</div>
            </div>

            <div className="text-center bg-gradient-to-br from-orange-50 to-yellow-50 rounded-3xl p-8 shadow-lg hover:shadow-xl transition-all duration-300">
              <div className="w-16 h-16 bg-orange-600 rounded-2xl flex items-center justify-center mx-auto mb-4 shadow-lg">
                <i className="ri-star-line text-white text-2xl w-8 h-8 flex items-center justify-center"></i>
              </div>
              <div className="text-3xl font-bold text-orange-600 mb-2">A+</div>
              <div className="text-gray-700 font-medium">School Rating</div>
            </div>
          </div>
        </div>
      </section>

      <Footer />
    </div>
  );
}
