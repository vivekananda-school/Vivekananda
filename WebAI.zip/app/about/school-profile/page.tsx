
'use client';

import Header from '../../../components/Header';
import Footer from '../../../components/Footer';

export default function SchoolProfile() {
  return (
    <div className="min-h-screen bg-white">
      <Header />

      {/* Hero Section */}
      <section className="relative py-24 overflow-hidden">
        <div 
          className="absolute inset-0 bg-cover bg-center bg-no-repeat"
          style={{
            backgroundImage: `url('https://readdy.ai/api/search-image?query=Comprehensive%20school%20campus%20aerial%20view%20showing%20academic%20buildings%2C%20sports%20facilities%2C%20green%20spaces%2C%20modern%20architecture%2C%20students%20on%20campus%2C%20complete%20educational%20infrastructure%2C%20inspiring%20institutional%20setting&width=1920&height=800&seq=profile-hero&orientation=landscape')`
          }}
        ></div>
        <div className="absolute inset-0 bg-gradient-to-br from-blue-900/85 via-blue-800/75 to-purple-900/70"></div>
        
        <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center transform perspective-1000">
            <div className="bg-gradient-to-r from-white/15 to-white/10 backdrop-blur-lg rounded-3xl p-8 md:p-12 shadow-2xl border border-white/20 transform hover:scale-105 transition-all duration-700">
              <h1 className="text-4xl md:text-6xl font-bold text-white mb-6 leading-tight drop-shadow-2xl">
                School <span className="bg-gradient-to-r from-yellow-300 via-blue-300 to-purple-300 bg-clip-text text-transparent">Profile</span>
              </h1>
              <p className="text-xl md:text-2xl text-blue-100 mb-8 leading-relaxed drop-shadow-lg max-w-3xl mx-auto">
                A comprehensive overview of our institution's history, achievements, and commitment to educational excellence.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* School Overview */}
      <section className="py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="max-w-4xl mx-auto">
            <div className="bg-white rounded-3xl shadow-2xl p-8 md:p-12 transform hover:shadow-3xl transition-all duration-500">
              <h2 className="text-3xl font-bold text-gray-900 mb-8 text-center">About Vivekananda International School</h2>
              
              <div className="prose prose-lg max-w-none text-gray-700 leading-relaxed space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-8">
                  <div className="bg-blue-50 rounded-2xl p-6 border border-blue-100">
                    <h3 className="text-xl font-semibold text-blue-900 mb-4">Established</h3>
                    <p className="text-3xl font-bold text-blue-600">1985</p>
                    <p className="text-blue-700 mt-2">39 years of educational excellence</p>
                  </div>
                  
                  <div className="bg-green-50 rounded-2xl p-6 border border-green-100">
                    <h3 className="text-xl font-semibold text-green-900 mb-4">Campus Size</h3>
                    <p className="text-3xl font-bold text-green-600">25 Acres</p>
                    <p className="text-green-700 mt-2">Sprawling green campus</p>
                  </div>
                </div>
                
                <p>
                  Vivekananda International School stands as a premier educational institution committed to nurturing young minds and shaping future leaders. Founded in 1985 with a vision to provide world-class education rooted in Indian values and global perspectives, our school has grown from a small community institution to one of the region's most respected educational establishments.
                </p>
                
                <p>
                  Our institution is named after Swami Vivekananda, the great Indian philosopher and educator, whose teachings inspire our educational philosophy. We believe in the holistic development of students, combining academic rigor with character building, cultural awareness, and social responsibility.
                </p>
                
                <p>
                  Over the years, we have maintained our commitment to excellence while adapting to the evolving needs of modern education. Our curriculum integrates traditional learning with innovative teaching methodologies, preparing students for success in an increasingly interconnected world.
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Key Statistics */}
      <section className="py-20 bg-blue-900">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-white mb-4">
              Our Numbers Speak
            </h2>
            <p className="text-xl text-blue-200 max-w-3xl mx-auto">
              Key statistics that reflect our growth, success, and commitment to education.
            </p>
          </div>

          <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
            <div className="text-center bg-white/10 backdrop-blur-lg rounded-3xl p-8 shadow-xl border border-white/20">
              <div className="text-4xl md:text-5xl font-bold text-white mb-2">2,500+</div>
              <div className="text-blue-200 text-lg">Current Students</div>
            </div>
            <div className="text-center bg-white/10 backdrop-blur-lg rounded-3xl p-8 shadow-xl border border-white/20">
              <div className="text-4xl md:text-5xl font-bold text-white mb-2">150+</div>
              <div className="text-blue-200 text-lg">Faculty Members</div>
            </div>
            <div className="text-center bg-white/10 backdrop-blur-lg rounded-3xl p-8 shadow-xl border border-white/20">
              <div className="text-4xl md:text-5xl font-bold text-white mb-2">15,000+</div>
              <div className="text-blue-200 text-lg">Alumni Worldwide</div>
            </div>
            <div className="text-center bg-white/10 backdrop-blur-lg rounded-3xl p-8 shadow-xl border border-white/20">
              <div className="text-4xl md:text-5xl font-bold text-white mb-2">98%</div>
              <div className="text-blue-200 text-lg">Success Rate</div>
            </div>
          </div>
        </div>
      </section>

      {/* Facilities */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
              World-Class Facilities
            </h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              State-of-the-art infrastructure designed to enhance learning and support comprehensive development.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            <div className="bg-gradient-to-br from-blue-50 to-purple-50 rounded-3xl p-8 shadow-lg hover:shadow-xl transition-all duration-300">
              <div className="w-16 h-16 bg-blue-600 rounded-2xl flex items-center justify-center mb-6 shadow-lg">
                <i className="ri-computer-line text-white text-2xl w-8 h-8 flex items-center justify-center"></i>
              </div>
              <h3 className="text-xl font-semibold text-gray-900 mb-4">Smart Classrooms</h3>
              <p className="text-gray-700">75 technology-enabled classrooms with interactive whiteboards, projectors, and high-speed internet connectivity.</p>
            </div>

            <div className="bg-gradient-to-br from-green-50 to-blue-50 rounded-3xl p-8 shadow-lg hover:shadow-xl transition-all duration-300">
              <div className="w-16 h-16 bg-green-600 rounded-2xl flex items-center justify-center mb-6 shadow-lg">
                <i className="ri-flask-line text-white text-2xl w-8 h-8 flex items-center justify-center"></i>
              </div>
              <h3 className="text-xl font-semibold text-gray-900 mb-4">Science Laboratories</h3>
              <p className="text-gray-700">Advanced physics, chemistry, and biology labs equipped with modern instruments and safety measures.</p>
            </div>

            <div className="bg-gradient-to-br from-purple-50 to-pink-50 rounded-3xl p-8 shadow-lg hover:shadow-xl transition-all duration-300">
              <div className="w-16 h-16 bg-purple-600 rounded-2xl flex items-center justify-center mb-6 shadow-lg">
                <i className="ri-book-3-line text-white text-2xl w-8 h-8 flex items-center justify-center"></i>
              </div>
              <h3 className="text-xl font-semibold text-gray-900 mb-4">Central Library</h3>
              <p className="text-gray-700">Extensive collection of 50,000+ books, digital resources, and quiet study areas for research and learning.</p>
            </div>

            <div className="bg-gradient-to-br from-orange-50 to-yellow-50 rounded-3xl p-8 shadow-lg hover:shadow-xl transition-all duration-300">
              <div className="w-16 h-16 bg-orange-600 rounded-2xl flex items-center justify-center mb-6 shadow-lg">
                <i className="ri-football-line text-white text-2xl w-8 h-8 flex items-center justify-center"></i>
              </div>
              <h3 className="text-xl font-semibold text-gray-900 mb-4">Sports Complex</h3>
              <p className="text-gray-700">Multi-purpose gymnasium, swimming pool, cricket ground, and courts for basketball, tennis, and badminton.</p>
            </div>

            <div className="bg-gradient-to-br from-red-50 to-orange-50 rounded-3xl p-8 shadow-lg hover:shadow-xl transition-all duration-300">
              <div className="w-16 h-16 bg-red-600 rounded-2xl flex items-center justify-center mb-6 shadow-lg">
                <i className="ri-palette-line text-white text-2xl w-8 h-8 flex items-center justify-center"></i>
              </div>
              <h3 className="text-xl font-semibold text-gray-900 mb-4">Arts & Crafts Center</h3>
              <p className="text-gray-700">Dedicated spaces for visual arts, music, dance, and drama with professional-grade equipment and studios.</p>
            </div>

            <div className="bg-gradient-to-br from-indigo-50 to-blue-50 rounded-3xl p-8 shadow-lg hover:shadow-xl transition-all duration-300">
              <div className="w-16 h-16 bg-indigo-600 rounded-2xl flex items-center justify-center mb-6 shadow-lg">
                <i className="ri-restaurant-line text-white text-2xl w-8 h-8 flex items-center justify-center"></i>
              </div>
              <h3 className="text-xl font-semibold text-gray-900 mb-4">Dining Facilities</h3>
              <p className="text-gray-700">Spacious cafeteria serving nutritious meals, with separate dining areas and modern kitchen facilities.</p>
            </div>
          </div>
        </div>
      </section>

      {/* Academic Programs */}
      <section className="py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
              Academic Programs
            </h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Comprehensive educational programs designed to meet diverse learning needs and prepare students for future success.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <div className="bg-white rounded-3xl shadow-2xl p-8 transform hover:shadow-3xl transition-all duration-500">
              <h3 className="text-2xl font-bold text-gray-900 mb-6">Primary Education (Grades K-5)</h3>
              <ul className="space-y-4 text-gray-700">
                <li className="flex items-start space-x-3">
                  <i className="ri-check-line text-green-600 mt-1 w-5 h-5 flex items-center justify-center"></i>
                  <span>Foundation literacy and numeracy programs</span>
                </li>
                <li className="flex items-start space-x-3">
                  <i className="ri-check-line text-green-600 mt-1 w-5 h-5 flex items-center justify-center"></i>
                  <span>Creative arts and physical education</span>
                </li>
                <li className="flex items-start space-x-3">
                  <i className="ri-check-line text-green-600 mt-1 w-5 h-5 flex items-center justify-center"></i>
                  <span>Social skills and character development</span>
                </li>
                <li className="flex items-start space-x-3">
                  <i className="ri-check-line text-green-600 mt-1 w-5 h-5 flex items-center justify-center"></i>
                  <span>Technology integration and digital literacy</span>
                </li>
              </ul>
            </div>

            <div className="bg-white rounded-3xl shadow-2xl p-8 transform hover:shadow-3xl transition-all duration-500">
              <h3 className="text-2xl font-bold text-gray-900 mb-6">Secondary Education (Grades 6-12)</h3>
              <ul className="space-y-4 text-gray-700">
                <li className="flex items-start space-x-3">
                  <i className="ri-check-line text-blue-600 mt-1 w-5 h-5 flex items-center justify-center"></i>
                  <span>CBSE and International curriculum options</span>
                </li>
                <li className="flex items-start space-x-3">
                  <i className="ri-check-line text-blue-600 mt-1 w-5 h-5 flex items-center justify-center"></i>
                  <span>Advanced placement and honors courses</span>
                </li>
                <li className="flex items-start space-x-3">
                  <i className="ri-check-line text-blue-600 mt-1 w-5 h-5 flex items-center justify-center"></i>
                  <span>Career guidance and university preparation</span>
                </li>
                <li className="flex items-start space-x-3">
                  <i className="ri-check-line text-blue-600 mt-1 w-5 h-5 flex items-center justify-center"></i>
                  <span>Leadership and community service programs</span>
                </li>
              </ul>
            </div>
          </div>
        </div>
      </section>

      {/* Awards and Recognition */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
              Awards & Recognition
            </h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Our commitment to excellence has been recognized through numerous prestigious awards and accreditations.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            <div className="text-center bg-gradient-to-br from-yellow-50 to-orange-50 rounded-3xl p-8 shadow-lg">
              <div className="w-16 h-16 bg-yellow-500 rounded-2xl flex items-center justify-center mx-auto mb-4 shadow-lg">
                <i className="ri-award-line text-white text-2xl w-8 h-8 flex items-center justify-center"></i>
              </div>
              <h3 className="text-lg font-semibold text-gray-900 mb-2">Best School Award</h3>
              <p className="text-gray-600 text-sm">National Education Excellence Awards 2023</p>
            </div>

            <div className="text-center bg-gradient-to-br from-blue-50 to-purple-50 rounded-3xl p-8 shadow-lg">
              <div className="w-16 h-16 bg-blue-500 rounded-2xl flex items-center justify-center mx-auto mb-4 shadow-lg">
                <i className="ri-star-line text-white text-2xl w-8 h-8 flex items-center justify-center"></i>
              </div>
              <h3 className="text-lg font-semibold text-gray-900 mb-2">5-Star Rating</h3>
              <p className="text-gray-600 text-sm">Department of Education Quality Assessment</p>
            </div>

            <div className="text-center bg-gradient-to-br from-green-50 to-blue-50 rounded-3xl p-8 shadow-lg">
              <div className="w-16 h-16 bg-green-500 rounded-2xl flex items-center justify-center mx-auto mb-4 shadow-lg">
                <i className="ri-shield-check-line text-white text-2xl w-8 h-8 flex items-center justify-center"></i>
              </div>
              <h3 className="text-lg font-semibold text-gray-900 mb-2">ISO Certification</h3>
              <p className="text-gray-600 text-sm">ISO 21001:2018 Educational Management</p>
            </div>

            <div className="text-center bg-gradient-to-br from-purple-50 to-pink-50 rounded-3xl p-8 shadow-lg">
              <div className="w-16 h-16 bg-purple-500 rounded-2xl flex items-center justify-center mx-auto mb-4 shadow-lg">
                <i className="ri-trophy-line text-white text-2xl w-8 h-8 flex items-center justify-center"></i>
              </div>
              <h3 className="text-lg font-semibold text-gray-900 mb-2">Innovation Award</h3>
              <p className="text-gray-600 text-sm">Educational Technology Innovation 2022</p>
            </div>
          </div>
        </div>
      </section>

      <Footer />
    </div>
  );
}
