
'use client';

import Header from '../../../components/Header';
import Footer from '../../../components/Footer';

export default function VisionMission() {
  return (
    <div className="min-h-screen bg-white">
      <Header />

      {/* Hero Section */}
      <section className="relative py-24 overflow-hidden">
        <div 
          className="absolute inset-0 bg-cover bg-center bg-no-repeat"
          style={{
            backgroundImage: `url('https://readdy.ai/api/search-image?query=Inspiring%20educational%20vision%20concept%20with%20students%20looking%20toward%20bright%20future%2C%20graduation%20ceremony%2C%20academic%20success%2C%20mountain%20peaks%20representing%20goals%20and%20aspirations%2C%20sunrise%20symbolizing%20hope%20and%20potential&width=1920&height=800&seq=vision-hero&orientation=landscape')`
          }}
        ></div>
        <div className="absolute inset-0 bg-gradient-to-br from-blue-900/85 via-blue-800/75 to-purple-900/70"></div>
        
        <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center transform perspective-1000">
            <div className="bg-gradient-to-r from-white/15 to-white/10 backdrop-blur-lg rounded-3xl p-8 md:p-12 shadow-2xl border border-white/20 transform hover:scale-105 transition-all duration-700">
              <h1 className="text-4xl md:text-6xl font-bold text-white mb-6 leading-tight drop-shadow-2xl">
                Our <span className="bg-gradient-to-r from-yellow-300 via-blue-300 to-purple-300 bg-clip-text text-transparent">Vision & Mission</span>
              </h1>
              <p className="text-xl md:text-2xl text-blue-100 mb-8 leading-relaxed drop-shadow-lg max-w-3xl mx-auto">
                Guiding principles that shape our educational philosophy and drive our commitment to excellence.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Vision Section */}
      <section className="py-20 bg-gradient-to-br from-blue-50 to-purple-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="max-w-4xl mx-auto">
            <div className="bg-white rounded-3xl shadow-2xl p-8 md:p-12 transform hover:shadow-3xl transition-all duration-500">
              <div className="text-center mb-12">
                <div className="w-24 h-24 bg-gradient-to-br from-blue-600 to-purple-600 rounded-3xl flex items-center justify-center mx-auto mb-6 shadow-xl">
                  <i className="ri-eye-line text-white text-3xl w-12 h-12 flex items-center justify-center"></i>
                </div>
                <h2 className="text-4xl font-bold text-gray-900 mb-6">Our Vision</h2>
              </div>
              
              <div className="bg-gradient-to-r from-blue-50 to-purple-50 rounded-2xl p-8 mb-8 border border-blue-100">
                <p className="text-2xl text-center text-gray-800 font-medium leading-relaxed">
                  "To be a globally recognized institution of educational excellence that nurtures innovative thinkers, ethical leaders, and compassionate global citizens who will shape a better tomorrow."
                </p>
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
                <div className="text-center">
                  <div className="w-16 h-16 bg-blue-100 rounded-2xl flex items-center justify-center mx-auto mb-4">
                    <i className="ri-lightbulb-line text-blue-600 text-2xl w-8 h-8 flex items-center justify-center"></i>
                  </div>
                  <h3 className="text-xl font-semibold text-gray-900 mb-3">Innovation</h3>
                  <p className="text-gray-600">Fostering creative thinking and problem-solving skills for the future.</p>
                </div>
                
                <div className="text-center">
                  <div className="w-16 h-16 bg-purple-100 rounded-2xl flex items-center justify-center mx-auto mb-4">
                    <i className="ri-user-star-line text-purple-600 text-2xl w-8 h-8 flex items-center justify-center"></i>
                  </div>
                  <h3 className="text-xl font-semibold text-gray-900 mb-3">Leadership</h3>
                  <p className="text-gray-600">Developing ethical leaders who inspire positive change.</p>
                </div>
                
                <div className="text-center">
                  <div className="w-16 h-16 bg-green-100 rounded-2xl flex items-center justify-center mx-auto mb-4">
                    <i className="ri-global-line text-green-600 text-2xl w-8 h-8 flex items-center justify-center"></i>
                  </div>
                  <h3 className="text-xl font-semibold text-gray-900 mb-3">Global Citizenship</h3>
                  <p className="text-gray-600">Preparing students to thrive in an interconnected world.</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Mission Section */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="max-w-4xl mx-auto">
            <div className="bg-gradient-to-br from-green-50 to-blue-50 rounded-3xl shadow-2xl p-8 md:p-12 transform hover:shadow-3xl transition-all duration-500">
              <div className="text-center mb-12">
                <div className="w-24 h-24 bg-gradient-to-br from-green-600 to-blue-600 rounded-3xl flex items-center justify-center mx-auto mb-6 shadow-xl">
                  <i className="ri-compass-3-line text-white text-3xl w-12 h-12 flex items-center justify-center"></i>
                </div>
                <h2 className="text-4xl font-bold text-gray-900 mb-6">Our Mission</h2>
              </div>
              
              <div className="bg-white rounded-2xl p-8 mb-8 shadow-lg border border-green-100">
                <p className="text-xl text-center text-gray-800 leading-relaxed mb-6">
                  To provide a comprehensive, innovative, and inclusive educational experience that empowers students to achieve academic excellence, develop strong character, and become responsible global citizens committed to making a positive impact on society.
                </p>
              </div>
              
              <div className="space-y-6">
                <div className="flex items-start space-x-4">
                  <div className="w-12 h-12 bg-blue-600 rounded-xl flex items-center justify-center flex-shrink-0 shadow-lg">
                    <i className="ri-book-open-line text-white text-lg w-6 h-6 flex items-center justify-center"></i>
                  </div>
                  <div>
                    <h3 className="text-xl font-semibold text-gray-900 mb-2">Academic Excellence</h3>
                    <p className="text-gray-700">Deliver world-class education through innovative teaching methods, cutting-edge technology, and personalized learning approaches that cater to diverse learning styles and abilities.</p>
                  </div>
                </div>
                
                <div className="flex items-start space-x-4">
                  <div className="w-12 h-12 bg-green-600 rounded-xl flex items-center justify-center flex-shrink-0 shadow-lg">
                    <i className="ri-heart-3-line text-white text-lg w-6 h-6 flex items-center justify-center"></i>
                  </div>
                  <div>
                    <h3 className="text-xl font-semibold text-gray-900 mb-2">Character Development</h3>
                    <p className="text-gray-700">Instill strong moral values, ethical principles, and social responsibility while fostering empathy, integrity, and respect for diversity in all our students.</p>
                  </div>
                </div>
                
                <div className="flex items-start space-x-4">
                  <div className="w-12 h-12 bg-purple-600 rounded-xl flex items-center justify-center flex-shrink-0 shadow-lg">
                    <i className="ri-community-line text-white text-lg w-6 h-6 flex items-center justify-center"></i>
                  </div>
                  <div>
                    <h3 className="text-xl font-semibold text-gray-900 mb-2">Community Engagement</h3>
                    <p className="text-gray-700">Create meaningful partnerships with families and the broader community to enhance learning experiences and contribute to social development.</p>
                  </div>
                </div>
                
                <div className="flex items-start space-x-4">
                  <div className="w-12 h-12 bg-orange-600 rounded-xl flex items-center justify-center flex-shrink-0 shadow-lg">
                    <i className="ri-seedling-line text-white text-lg w-6 h-6 flex items-center justify-center"></i>
                  </div>
                  <div>
                    <h3 className="text-xl font-semibold text-gray-900 mb-2">Holistic Growth</h3>
                    <p className="text-gray-700">Provide comprehensive development opportunities in academics, arts, sports, and leadership to nurture well-rounded individuals prepared for future challenges.</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Core Values */}
      <section className="py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
              Our Core Values
            </h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              The fundamental principles that guide every aspect of our educational approach and school culture.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            <div className="bg-white rounded-3xl p-8 shadow-lg hover:shadow-xl transition-all duration-300 transform hover:scale-105">
              <div className="w-16 h-16 bg-red-100 rounded-2xl flex items-center justify-center mb-6">
                <i className="ri-heart-line text-red-600 text-2xl w-8 h-8 flex items-center justify-center"></i>
              </div>
              <h3 className="text-xl font-semibold text-gray-900 mb-4">Integrity</h3>
              <p className="text-gray-700">Upholding honesty, transparency, and ethical behavior in all our actions and decisions.</p>
            </div>

            <div className="bg-white rounded-3xl p-8 shadow-lg hover:shadow-xl transition-all duration-300 transform hover:scale-105">
              <div className="w-16 h-16 bg-blue-100 rounded-2xl flex items-center justify-center mb-6">
                <i className="ri-star-line text-blue-600 text-2xl w-8 h-8 flex items-center justify-center"></i>
              </div>
              <h3 className="text-xl font-semibold text-gray-900 mb-4">Excellence</h3>
              <p className="text-gray-700">Striving for the highest standards in education, personal growth, and achievement.</p>
            </div>

            <div className="bg-white rounded-3xl p-8 shadow-lg hover:shadow-xl transition-all duration-300 transform hover:scale-105">
              <div className="w-16 h-16 bg-green-100 rounded-2xl flex items-center justify-center mb-6">
                <i className="ri-group-line text-green-600 text-2xl w-8 h-8 flex items-center justify-center"></i>
              </div>
              <h3 className="text-xl font-semibold text-gray-900 mb-4">Respect</h3>
              <p className="text-gray-700">Valuing diversity, promoting inclusivity, and treating everyone with dignity and kindness.</p>
            </div>

            <div className="bg-white rounded-3xl p-8 shadow-lg hover:shadow-xl transition-all duration-300 transform hover:scale-105">
              <div className="w-16 h-16 bg-purple-100 rounded-2xl flex items-center justify-center mb-6">
                <i className="ri-lightbulb-line text-purple-600 text-2xl w-8 h-8 flex items-center justify-center"></i>
              </div>
              <h3 className="text-xl font-semibold text-gray-900 mb-4">Innovation</h3>
              <p className="text-gray-700">Embracing creativity, encouraging critical thinking, and adapting to changing educational needs.</p>
            </div>

            <div className="bg-white rounded-3xl p-8 shadow-lg hover:shadow-xl transition-all duration-300 transform hover:scale-105">
              <div className="w-16 h-16 bg-yellow-100 rounded-2xl flex items-center justify-center mb-6">
                <i className="ri-hand-heart-line text-yellow-600 text-2xl w-8 h-8 flex items-center justify-center"></i>
              </div>
              <h3 className="text-xl font-semibold text-gray-900 mb-4">Compassion</h3>
              <p className="text-gray-700">Fostering empathy, understanding, and a commitment to helping others in our community.</p>
            </div>

            <div className="bg-white rounded-3xl p-8 shadow-lg hover:shadow-xl transition-all duration-300 transform hover:scale-105">
              <div className="w-16 h-16 bg-indigo-100 rounded-2xl flex items-center justify-center mb-6">
                <i className="ri-shield-check-line text-indigo-600 text-2xl w-8 h-8 flex items-center justify-center"></i>
              </div>
              <h3 className="text-xl font-semibold text-gray-900 mb-4">Responsibility</h3>
              <p className="text-gray-700">Taking ownership of our actions and contributing positively to society and the environment.</p>
            </div>
          </div>
        </div>
      </section>

      <Footer />
    </div>
  );
}
