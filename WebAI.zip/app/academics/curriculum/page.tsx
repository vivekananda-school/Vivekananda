
'use client';

import { useState } from 'react';
import Header from '../../../components/Header';
import Footer from '../../../components/Footer';

const Curriculum = () => {
  const [selectedGrade, setSelectedGrade] = useState('Elementary');

  const gradeCategories = [
    { id: 'Elementary', name: 'Elementary (K-5)', grades: 'Kindergarten - Grade 5' },
    { id: 'Middle', name: 'Middle School (6-8)', grades: 'Grade 6 - Grade 8' },
    { id: 'High', name: 'High School (9-12)', grades: 'Grade 9 - Grade 12' }
  ];

  const curriculumData = {
    Elementary: {
      coreSubjects: [
        { 
          subject: 'English Language Arts', 
          description: 'Reading comprehension, writing skills, grammar, vocabulary, and literature appreciation',
          skills: ['Phonics and Reading Fluency', 'Creative Writing', 'Grammar and Vocabulary', 'Literature Analysis']
        },
        { 
          subject: 'Mathematics', 
          description: 'Number sense, basic operations, geometry, measurement, and problem-solving',
          skills: ['Number Operations', 'Geometry and Shapes', 'Measurement and Data', 'Problem Solving']
        },
        { 
          subject: 'Science', 
          description: 'Earth science, life science, physical science, and scientific inquiry methods',
          skills: ['Scientific Method', 'Life Cycles', 'Weather and Climate', 'Matter and Energy']
        },
        { 
          subject: 'Social Studies', 
          description: 'Community, geography, history, civics, and cultural awareness',
          skills: ['Community Helpers', 'Maps and Geography', 'American History', 'Citizenship']
        }
      ],
      specialSubjects: [
        'Art Education', 'Music Education', 'Physical Education', 'Library Skills', 'Computer Literacy', 'Character Education'
      ]
    },
    Middle: {
      coreSubjects: [
        { 
          subject: 'English Language Arts', 
          description: 'Advanced reading, essay writing, research skills, and literary analysis',
          skills: ['Essay Writing', 'Research Methods', 'Literary Analysis', 'Public Speaking']
        },
        { 
          subject: 'Mathematics', 
          description: 'Pre-algebra, algebra fundamentals, geometry, and statistical concepts',
          skills: ['Pre-Algebra', 'Geometric Reasoning', 'Data Analysis', 'Mathematical Modeling']
        },
        { 
          subject: 'Science', 
          description: 'Biology, chemistry, physics, and earth sciences with laboratory work',
          skills: ['Laboratory Techniques', 'Cell Biology', 'Chemical Reactions', 'Forces and Motion']
        },
        { 
          subject: 'Social Studies', 
          description: 'World history, geography, civics, and cultural studies',
          skills: ['World Civilizations', 'Geographic Analysis', 'Government Systems', 'Cultural Diversity']
        }
      ],
      specialSubjects: [
        'World Languages (Spanish/French)', 'Advanced Art', 'Band/Orchestra', 'Technology Education', 'Health Education', 'Study Skills'
      ]
    },
    High: {
      coreSubjects: [
        { 
          subject: 'English', 
          description: 'Advanced composition, literature analysis, and critical thinking skills',
          skills: ['Advanced Composition', 'Literary Criticism', 'Research Writing', 'Debate and Discussion']
        },
        { 
          subject: 'Mathematics', 
          description: 'Algebra, geometry, trigonometry, pre-calculus, and calculus options',
          skills: ['Advanced Algebra', 'Trigonometry', 'Statistics', 'Calculus (AP Available)']
        },
        { 
          subject: 'Science', 
          description: 'Biology, chemistry, physics, and advanced placement science courses',
          skills: ['Advanced Biology', 'Organic Chemistry', 'Physics Mechanics', 'AP Science Courses']
        },
        { 
          subject: 'Social Studies', 
          description: 'World history, US history, government, economics, and AP social studies',
          skills: ['AP US History', 'Government & Politics', 'Economics', 'Psychology']
        }
      ],
      specialSubjects: [
        'Advanced Placement Courses', 'Dual Enrollment', 'World Languages', 'Fine Arts', 'Career Technical Education', 'Advanced Technology'
      ]
    }
  };

  const apCourses = [
    'AP English Literature', 'AP English Language', 'AP Calculus AB/BC', 'AP Statistics',
    'AP Biology', 'AP Chemistry', 'AP Physics', 'AP Environmental Science',
    'AP US History', 'AP World History', 'AP Government', 'AP Psychology',
    'AP Spanish Language', 'AP French Language', 'AP Art History', 'AP Studio Art'
  ];

  const graduationRequirements = [
    { subject: 'English', credits: '4 Credits', description: 'Four years of English language arts' },
    { subject: 'Mathematics', credits: '4 Credits', description: 'Including Algebra II or higher' },
    { subject: 'Science', credits: '3 Credits', description: 'Including Biology, Chemistry, and Physics' },
    { subject: 'Social Studies', credits: '3 Credits', description: 'Including US History and Government' },
    { subject: 'World Languages', credits: '2 Credits', description: 'Two years of the same language' },
    { subject: 'Fine Arts', credits: '1 Credit', description: 'Art, Music, Drama, or Dance' },
    { subject: 'Physical Education', credits: '1 Credit', description: 'Health and Physical Education' },
    { subject: 'Electives', credits: '6 Credits', description: 'Student choice electives' }
  ];

  return (
    <div className="min-h-screen bg-gray-50">
      <Header />
      
      <div className="relative bg-gradient-to-r from-green-600 to-blue-600 text-white py-20">
        <div 
          className="absolute inset-0 bg-cover bg-center bg-no-repeat opacity-20"
          style={{
            backgroundImage: `url('https://readdy.ai/api/search-image?query=Modern%20curriculum%20and%20syllabus%20materials%20with%20textbooks%2C%20educational%20resources%2C%20academic%20planning%20documents%2C%20classroom%20learning%20environment%2C%20professional%20education%20setting%20with%20organized%20study%20materials&width=1200&height=400&seq=curriculum-hero&orientation=landscape')`
          }}
        ></div>
        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h1 className="text-5xl font-bold mb-6">Curriculum & Syllabus</h1>
          <p className="text-xl text-green-100 max-w-3xl mx-auto">
            Comprehensive academic programs designed to challenge and inspire students at every level
          </p>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        {/* Grade Level Selector */}
        <div className="mb-12">
          <h2 className="text-3xl font-bold text-gray-900 mb-8 text-center">Academic Programs by Grade Level</h2>
          <div className="flex flex-wrap justify-center gap-4">
            {gradeCategories.map((category) => (
              <button
                key={category.id}
                onClick={() => setSelectedGrade(category.id)}
                className={`px-8 py-4 rounded-xl font-medium transition-all duration-200 whitespace-nowrap ${
                  selectedGrade === category.id
                    ? 'bg-green-600 text-white shadow-lg transform scale-105'
                    : 'bg-white text-gray-700 hover:bg-green-50 hover:text-green-600 border border-gray-200 shadow-md'
                }`}
              >
                <div className="text-center">
                  <div className="font-bold">{category.name}</div>
                  <div className="text-sm opacity-75">{category.grades}</div>
                </div>
              </button>
            ))}
          </div>
        </div>

        {/* Core Subjects */}
        <div className="mb-12">
          <h3 className="text-2xl font-bold text-gray-900 mb-8">Core Subjects</h3>
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            {curriculumData[selectedGrade as keyof typeof curriculumData].coreSubjects.map((subject, index) => (
              <div key={index} className="bg-white rounded-xl shadow-lg p-8 border border-gray-100 hover:shadow-xl transition-shadow duration-300">
                <div className="flex items-center mb-4">
                  <div className="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center mr-4">
                    <i className="ri-book-line text-green-600 w-6 h-6 flex items-center justify-center"></i>
                  </div>
                  <h4 className="text-xl font-bold text-gray-900">{subject.subject}</h4>
                </div>
                <p className="text-gray-600 mb-4">{subject.description}</p>
                <div>
                  <h5 className="font-semibold text-gray-900 mb-2">Key Skills Developed:</h5>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                    {subject.skills.map((skill, skillIndex) => (
                      <div key={skillIndex} className="flex items-center">
                        <i className="ri-check-line text-green-500 w-4 h-4 flex items-center justify-center mr-2"></i>
                        <span className="text-sm text-gray-700">{skill}</span>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Special Subjects */}
        <div className="mb-12">
          <h3 className="text-2xl font-bold text-gray-900 mb-8">Special Subjects & Enrichment</h3>
          <div className="bg-white rounded-xl shadow-lg p-8 border border-gray-100">
            <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
              {curriculumData[selectedGrade as keyof typeof curriculumData].specialSubjects.map((subject, index) => (
                <div key={index} className="text-center p-4 bg-blue-50 rounded-lg hover:bg-blue-100 transition-colors duration-200">
                  <i className="ri-star-line text-blue-600 w-8 h-8 flex items-center justify-center mx-auto mb-2"></i>
                  <span className="text-sm font-medium text-gray-900">{subject}</span>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* High School Specific Content */}
        {selectedGrade === 'High' && (
          <>
            {/* Advanced Placement Courses */}
            <div className="mb-12">
              <h3 className="text-2xl font-bold text-gray-900 mb-8">Advanced Placement (AP) Courses</h3>
              <div className="bg-white rounded-xl shadow-lg p-8 border border-gray-100">
                <p className="text-gray-600 mb-6">
                  Our comprehensive AP program offers college-level coursework and the opportunity to earn college credit while in high school.
                </p>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                  {apCourses.map((course, index) => (
                    <div key={index} className="bg-gradient-to-r from-purple-50 to-blue-50 rounded-lg p-4 border border-purple-100">
                      <span className="text-sm font-medium text-gray-900">{course}</span>
                    </div>
                  ))}
                </div>
              </div>
            </div>

            {/* Graduation Requirements */}
            <div className="mb-12">
              <h3 className="text-2xl font-bold text-gray-900 mb-8">Graduation Requirements</h3>
              <div className="bg-white rounded-xl shadow-lg border border-gray-100">
                <div className="p-8">
                  <p className="text-gray-600 mb-6">
                    Students must earn a minimum of 24 credits to graduate, distributed across the following subject areas:
                  </p>
                  <div className="space-y-4">
                    {graduationRequirements.map((req, index) => (
                      <div key={index} className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
                        <div className="flex-1">
                          <h4 className="font-semibold text-gray-900">{req.subject}</h4>
                          <p className="text-sm text-gray-600">{req.description}</p>
                        </div>
                        <div className="ml-4">
                          <span className="bg-blue-600 text-white px-3 py-1 rounded-full text-sm font-medium">
                            {req.credits}
                          </span>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          </>
        )}

        {/* Assessment and Evaluation */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          <div className="bg-white rounded-xl shadow-lg p-8 border border-gray-100">
            <h3 className="text-2xl font-bold text-gray-900 mb-6">Assessment Methods</h3>
            <div className="space-y-4">
              <div className="flex items-start space-x-3">
                <i className="ri-file-text-line text-blue-600 w-5 h-5 flex items-center justify-center mt-1"></i>
                <div>
                  <h4 className="font-semibold text-gray-900">Formative Assessment</h4>
                  <p className="text-sm text-gray-600">Ongoing evaluation through quizzes, projects, and class participation</p>
                </div>
              </div>
              <div className="flex items-start space-x-3">
                <i className="ri-award-line text-blue-600 w-5 h-5 flex items-center justify-center mt-1"></i>
                <div>
                  <h4 className="font-semibold text-gray-900">Summative Assessment</h4>
                  <p className="text-sm text-gray-600">Comprehensive tests, final projects, and standardized assessments</p>
                </div>
              </div>
              <div className="flex items-start space-x-3">
                <i className="ri-presentation-line text-blue-600 w-5 h-5 flex items-center justify-center mt-1"></i>
                <div>
                  <h4 className="font-semibold text-gray-900">Performance-Based</h4>
                  <p className="text-sm text-gray-600">Presentations, portfolios, and practical demonstrations</p>
                </div>
              </div>
            </div>
          </div>

          <div className="bg-white rounded-xl shadow-lg p-8 border border-gray-100">
            <h3 className="text-2xl font-bold text-gray-900 mb-6">Academic Support</h3>
            <div className="space-y-4">
              <div className="flex items-start space-x-3">
                <i className="ri-group-line text-green-600 w-5 h-5 flex items-center justify-center mt-1"></i>
                <div>
                  <h4 className="font-semibold text-gray-900">Tutoring Services</h4>
                  <p className="text-sm text-gray-600">Peer and teacher-led tutoring in all subject areas</p>
                </div>
              </div>
              <div className="flex items-start space-x-3">
                <i className="ri-calendar-check-line text-green-600 w-5 h-5 flex items-center justify-center mt-1"></i>
                <div>
                  <h4 className="font-semibold text-gray-900">Study Hall</h4>
                  <p className="text-sm text-gray-600">Supervised study periods with academic assistance available</p>
                </div>
              </div>
              <div className="flex items-start space-x-3">
                <i className="ri-user-heart-line text-green-600 w-5 h-5 flex items-center justify-center mt-1"></i>
                <div>
                  <h4 className="font-semibold text-gray-900">Academic Counseling</h4>
                  <p className="text-sm text-gray-600">Individual guidance for course selection and academic planning</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <Footer />
    </div>
  );
};

export default Curriculum;
