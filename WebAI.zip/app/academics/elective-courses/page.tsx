
'use client';

import { useState } from 'react';
import Header from '../../../components/Header';
import Footer from '../../../components/Footer';

const ElectiveCourses = () => {
  const [selectedCategory, setSelectedCategory] = useState('All');

  const categories = [
    { id: 'All', name: 'All Electives', count: 24 },
    { id: 'Arts', name: 'Arts & Creative', count: 8 },
    { id: 'Technology', name: 'Technology', count: 6 },
    { id: 'Languages', name: 'World Languages', count: 4 },
    { id: 'Career', name: 'Career Prep', count: 6 }
  ];

  const electives = [
    {
      id: 1,
      title: 'Digital Photography',
      category: 'Arts',
      grade: '9-12',
      duration: 'Semester',
      description: 'Learn the fundamentals of digital photography, composition, lighting, and photo editing using professional software.',
      skills: ['Camera Operation', 'Photo Composition', 'Adobe Photoshop', 'Portfolio Development'],
      prerequisites: 'None',
      image: 'https://readdy.ai/api/search-image?query=Student%20learning%20digital%20photography%20in%20modern%20classroom%2C%20camera%20equipment%2C%20photo%20editing%20on%20computers%2C%20creative%20art%20studio%20environment%2C%20professional%20photography%20setup&width=400&height=300&seq=digital-photography&orientation=landscape'
    },
    {
      id: 2,
      title: 'Web Development',
      category: 'Technology',
      grade: '10-12',
      duration: 'Year',
      description: 'Build modern websites using HTML, CSS, JavaScript, and popular frameworks. Create responsive and interactive web applications.',
      skills: ['HTML/CSS', 'JavaScript', 'Responsive Design', 'Git/GitHub'],
      prerequisites: 'Computer Science I or equivalent',
      image: 'https://readdy.ai/api/search-image?query=Students%20coding%20and%20web%20development%20in%20computer%20lab%2C%20multiple%20monitors%20showing%20code%2C%20modern%20technology%20classroom%2C%20programming%20environment%20with%20laptops%20and%20coding%20interfaces&width=400&height=300&seq=web-development&orientation=landscape'
    },
    {
      id: 3,
      title: 'Spanish Conversation',
      category: 'Languages',
      grade: '9-12',
      duration: 'Semester',
      description: 'Develop fluency in Spanish through immersive conversation practice, cultural exploration, and real-world communication scenarios.',
      skills: ['Conversational Spanish', 'Cultural Awareness', 'Pronunciation', 'Practical Communication'],
      prerequisites: 'Spanish II',
      image: 'https://readdy.ai/api/search-image?query=Students%20in%20Spanish%20language%20class%20having%20conversation%20practice%2C%20cultural%20materials%2C%20interactive%20language%20learning%20environment%2C%20diverse%20students%20speaking%20and%20learning%20together&width=400&height=300&seq=spanish-conversation&orientation=landscape'
    },
    {
      id: 4,
      title: 'Entrepreneurship',
      category: 'Career',
      grade: '11-12',
      duration: 'Semester',
      description: 'Learn to develop business ideas, create business plans, understand market research, and explore startup fundamentals.',
      skills: ['Business Planning', 'Market Research', 'Financial Literacy', 'Presentation Skills'],
      prerequisites: 'Economics recommended',
      image: 'https://readdy.ai/api/search-image?query=High%20school%20students%20in%20entrepreneurship%20class%20with%20business%20presentations%2C%20startup%20planning%20materials%2C%20professional%20classroom%20setting%2C%20students%20presenting%20business%20ideas&width=400&height=300&seq=entrepreneurship&orientation=landscape'
    },
    {
      id: 5,
      title: 'Graphic Design',
      category: 'Arts',
      grade: '9-12',
      duration: 'Semester',
      description: 'Master design principles using industry-standard software to create logos, posters, brochures, and digital media.',
      skills: ['Adobe Creative Suite', 'Design Principles', 'Typography', 'Brand Development'],
      prerequisites: 'Art I or Digital Arts',
      image: 'https://readdy.ai/api/search-image?query=Students%20creating%20graphic%20designs%20on%20computers%20with%20Adobe%20software%2C%20colorful%20design%20projects%2C%20modern%20art%20and%20technology%20classroom%2C%20creative%20workspace%20with%20design%20materials&width=400&height=300&seq=graphic-design&orientation=landscape'
    },
    {
      id: 6,
      title: 'Robotics Engineering',
      category: 'Technology',
      grade: '9-12',
      duration: 'Year',
      description: 'Design, build, and program robots using LEGO Mindstorms and Arduino platforms. Participate in robotics competitions.',
      skills: ['Programming', 'Mechanical Design', 'Problem Solving', 'Teamwork'],
      prerequisites: 'Algebra I',
      image: 'https://readdy.ai/api/search-image?query=Students%20building%20and%20programming%20robots%20in%20engineering%20classroom%2C%20robotics%20equipment%2C%20STEM%20learning%20environment%2C%20hands-on%20technology%20education%20with%20robot%20prototypes&width=400&height=300&seq=robotics-engineering&orientation=landscape'
    },
    {
      id: 7,
      title: 'French Culture & Language',
      category: 'Languages',
      grade: '9-12',
      duration: 'Semester',
      description: 'Explore French culture, history, cuisine, and customs while advancing language skills through authentic materials.',
      skills: ['French Language', 'Cultural Understanding', 'Communication', 'Critical Thinking'],
      prerequisites: 'French I',
      image: 'https://readdy.ai/api/search-image?query=Students%20learning%20French%20culture%20and%20language%2C%20French%20cultural%20materials%20and%20decorations%2C%20language%20classroom%20with%20cultural%20artifacts%2C%20interactive%20French%20learning%20environment&width=400&height=300&seq=french-culture&orientation=landscape'
    },
    {
      id: 8,
      title: 'Video Production',
      category: 'Arts',
      grade: '10-12',
      duration: 'Semester',
      description: 'Learn video creation from concept to completion, including scripting, filming, editing, and post-production techniques.',
      skills: ['Video Editing', 'Storytelling', 'Camera Work', 'Audio Production'],
      prerequisites: 'None',
      image: 'https://readdy.ai/api/search-image?query=Students%20creating%20videos%20with%20professional%20cameras%20and%20editing%20equipment%2C%20media%20production%20classroom%2C%20video%20editing%20software%20on%20screens%2C%20creative%20filmmaking%20environment&width=400&height=300&seq=video-production&orientation=landscape'
    },
    {
      id: 9,
      title: 'Cybersecurity Fundamentals',
      category: 'Technology',
      grade: '11-12',
      duration: 'Semester',
      description: 'Introduction to cybersecurity principles, ethical hacking, network security, and digital privacy protection.',
      skills: ['Network Security', 'Ethical Hacking', 'Risk Assessment', 'Digital Forensics'],
      prerequisites: 'Computer Science I',
      image: 'https://readdy.ai/api/search-image?query=Students%20learning%20cybersecurity%20in%20computer%20lab%2C%20network%20security%20diagrams%2C%20modern%20technology%20classroom%2C%20cybersecurity%20education%20with%20multiple%20computer%20screens&width=400&height=300&seq=cybersecurity&orientation=landscape'
    },
    {
      id: 10,
      title: 'Culinary Arts',
      category: 'Career',
      grade: '9-12',
      duration: 'Semester',
      description: 'Master basic cooking techniques, food safety, nutrition, and explore international cuisines in a professional kitchen setting.',
      skills: ['Cooking Techniques', 'Food Safety', 'Menu Planning', 'Culinary Presentation'],
      prerequisites: 'None',
      image: 'https://readdy.ai/api/search-image?query=Students%20cooking%20in%20professional%20school%20kitchen%2C%20culinary%20arts%20classroom%20with%20cooking%20stations%2C%20food%20preparation%2C%20modern%20kitchen%20equipment%20and%20cooking%20utensils&width=400&height=300&seq=culinary-arts&orientation=landscape'
    },
    {
      id: 11,
      title: 'Theater Arts',
      category: 'Arts',
      grade: '9-12',
      duration: 'Year',
      description: 'Develop acting skills, stage presence, and theatrical knowledge through performance, script analysis, and production work.',
      skills: ['Acting Techniques', 'Stage Presence', 'Script Analysis', 'Character Development'],
      prerequisites: 'None',
      image: 'https://readdy.ai/api/search-image?query=Students%20rehearsing%20on%20theater%20stage%2C%20drama%20classroom%20with%20stage%20lighting%2C%20theatrical%20performance%20practice%2C%20school%20auditorium%20with%20students%20acting&width=400&height=300&seq=theater-arts&orientation=landscape'
    },
    {
      id: 12,
      title: 'Financial Literacy',
      category: 'Career',
      grade: '11-12',
      duration: 'Semester',
      description: 'Learn essential financial skills including budgeting, investing, taxes, credit, and personal financial planning.',
      skills: ['Budgeting', 'Investment Basics', 'Tax Preparation', 'Credit Management'],
      prerequisites: 'Algebra I',
      image: 'https://readdy.ai/api/search-image?query=Students%20learning%20financial%20literacy%20with%20calculators%20and%20financial%20documents%2C%20classroom%20with%20charts%20and%20graphs%2C%20practical%20money%20management%20education%20environment&width=400&height=300&seq=financial-literacy&orientation=landscape'
    }
  ];

  const filteredElectives = selectedCategory === 'All' 
    ? electives 
    : electives.filter(elective => elective.category === selectedCategory);

  const getGradeColor = (grade: string) => {
    if (grade.includes('9')) return 'bg-green-100 text-green-800';
    if (grade.includes('10')) return 'bg-blue-100 text-blue-800';
    if (grade.includes('11')) return 'bg-purple-100 text-purple-800';
    return 'bg-orange-100 text-orange-800';
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <Header />
      
      <div className="relative bg-gradient-to-r from-purple-600 to-pink-600 text-white py-20">
        <div 
          className="absolute inset-0 bg-cover bg-center bg-no-repeat opacity-20"
          style={{
            backgroundImage: `url('https://readdy.ai/api/search-image?query=Diverse%20elective%20courses%20and%20extracurricular%20activities%2C%20students%20engaged%20in%20various%20creative%20and%20technical%20subjects%2C%20modern%20educational%20facilities%20with%20art%2C%20technology%2C%20and%20specialized%20learning%20spaces&width=1200&height=400&seq=elective-courses-hero&orientation=landscape')`
          }}
        ></div>
        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h1 className="text-5xl font-bold mb-6">Elective Courses</h1>
          <p className="text-xl text-purple-100 max-w-3xl mx-auto">
            Explore your passions and discover new interests through our diverse selection of elective courses
          </p>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        {/* Category Filter */}
        <div className="mb-12">
          <h2 className="text-3xl font-bold text-gray-900 mb-8 text-center">Course Categories</h2>
          <div className="flex flex-wrap justify-center gap-4">
            {categories.map((category) => (
              <button
                key={category.id}
                onClick={() => setSelectedCategory(category.id)}
                className={`px-6 py-3 rounded-xl font-medium transition-all duration-200 whitespace-nowrap ${
                  selectedCategory === category.id
                    ? 'bg-purple-600 text-white shadow-lg transform scale-105'
                    : 'bg-white text-gray-700 hover:bg-purple-50 hover:text-purple-600 border border-gray-200 shadow-md'
                }`}
              >
                <div className="flex items-center space-x-2">
                  <span>{category.name}</span>
                  <span className="bg-gray-200 text-gray-600 text-xs px-2 py-1 rounded-full">
                    {category.count}
                  </span>
                </div>
              </button>
            ))}
          </div>
        </div>

        {/* Course Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {filteredElectives.map((course) => (
            <div key={course.id} className="bg-white rounded-xl shadow-lg overflow-hidden border border-gray-100 hover:shadow-xl transition-shadow duration-300">
              <div className="h-48 bg-gray-200 overflow-hidden">
                <img 
                  src={course.image} 
                  alt={course.title}
                  className="w-full h-full object-cover object-top hover:scale-105 transition-transform duration-300"
                />
              </div>
              
              <div className="p-6">
                <div className="flex items-center justify-between mb-3">
                  <span className={`px-3 py-1 rounded-full text-xs font-medium ${getGradeColor(course.grade)}`}>
                    Grades {course.grade}
                  </span>
                  <span className="text-sm text-gray-500">{course.duration}</span>
                </div>
                
                <h3 className="text-xl font-bold text-gray-900 mb-2">{course.title}</h3>
                <p className="text-gray-600 text-sm mb-4 line-clamp-3">{course.description}</p>
                
                <div className="mb-4">
                  <h4 className="font-semibold text-gray-900 mb-2 text-sm">Skills You'll Learn:</h4>
                  <div className="flex flex-wrap gap-1">
                    {course.skills.slice(0, 3).map((skill, index) => (
                      <span key={index} className="bg-gray-100 text-gray-700 px-2 py-1 rounded text-xs">
                        {skill}
                      </span>
                    ))}
                    {course.skills.length > 3 && (
                      <span className="text-gray-500 text-xs">+{course.skills.length - 3} more</span>
                    )}
                  </div>
                </div>
                
                <div className="border-t border-gray-100 pt-4">
                  <div className="flex items-center justify-between text-sm">
                    <span className="text-gray-500">Prerequisites:</span>
                    <span className="text-gray-700 font-medium">{course.prerequisites}</span>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Course Selection Information */}
        <div className="mt-16 bg-white rounded-xl shadow-lg p-8 border border-gray-100">
          <h3 className="text-2xl font-bold text-gray-900 mb-6 text-center">Course Selection Guidelines</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            <div className="text-center">
              <div className="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <i className="ri-calendar-check-line text-blue-600 w-8 h-8 flex items-center justify-center"></i>
              </div>
              <h4 className="font-semibold text-gray-900 mb-2">Registration Period</h4>
              <p className="text-sm text-gray-600">Course selection opens in March for the following academic year</p>
            </div>
            
            <div className="text-center">
              <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <i className="ri-bookmark-line text-green-600 w-8 h-8 flex items-center justify-center"></i>
              </div>
              <h4 className="font-semibold text-gray-900 mb-2">Course Limits</h4>
              <p className="text-sm text-gray-600">Students may select 2-3 electives per semester based on grade level</p>
            </div>
            
            <div className="text-center">
              <div className="w-16 h-16 bg-purple-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <i className="ri-user-star-line text-purple-600 w-8 h-8 flex items-center justify-center"></i>
              </div>
              <h4 className="font-semibold text-gray-900 mb-2">Academic Counseling</h4>
              <p className="text-sm text-gray-600">Meet with counselors to plan your elective pathway and career goals</p>
            </div>
            
            <div className="text-center">
              <div className="w-16 h-16 bg-orange-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <i className="ri-award-line text-orange-600 w-8 h-8 flex items-center justify-center"></i>
              </div>
              <h4 className="font-semibold text-gray-900 mb-2">Credit Options</h4>
              <p className="text-sm text-gray-600">Some electives may count toward graduation requirements or college prep</p>
            </div>
          </div>
        </div>

        {/* Contact Information */}
        <div className="mt-12 bg-gradient-to-r from-purple-600 to-pink-600 rounded-xl text-white p-8">
          <div className="text-center">
            <h3 className="text-2xl font-bold mb-4">Need Help Choosing Courses?</h3>
            <p className="text-purple-100 mb-6">
              Our academic counselors are here to help you select the perfect electives to match your interests and goals.
            </p>
            <div className="flex flex-col sm:flex-row justify-center items-center space-y-4 sm:space-y-0 sm:space-x-8">
              <div className="flex items-center space-x-2">
                <i className="ri-phone-line w-5 h-5 flex items-center justify-center"></i>
                <span>(555) 123-4567 ext. 205</span>
              </div>
              <div className="flex items-center space-x-2">
                <i className="ri-mail-line w-5 h-5 flex items-center justify-center"></i>
                <span>counseling@vivekananda-school.edu</span>
              </div>
            </div>
          </div>
        </div>
      </div>

      <Footer />
    </div>
  );
};

export default ElectiveCourses;
