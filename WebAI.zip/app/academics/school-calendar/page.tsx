
'use client';

import { useState } from 'react';
import Header from '../../../components/Header';
import Footer from '../../../components/Footer';

const SchoolCalendar = () => {
  const [selectedTerm, setSelectedTerm] = useState('Fall 2024');

  const terms = ['Fall 2024', 'Winter 2024', 'Spring 2025', 'Summer 2025'];

  const calendarEvents = {
    'Fall 2024': [
      { date: 'Aug 15-16', event: 'New Student Orientation', type: 'orientation' },
      { date: 'Aug 19', event: 'First Day of School', type: 'academic' },
      { date: 'Sep 2', event: 'Labor Day - No School', type: 'holiday' },
      { date: 'Sep 15', event: 'Parent-Teacher Conferences', type: 'meeting' },
      { date: 'Oct 10', event: 'Columbus Day - No School', type: 'holiday' },
      { date: 'Oct 31', event: 'Halloween Celebration', type: 'event' },
      { date: 'Nov 11', event: 'Veterans Day - No School', type: 'holiday' },
      { date: 'Nov 25-29', event: 'Thanksgiving Break', type: 'break' },
      { date: 'Dec 16', event: 'Fall Semester Final Exams Begin', type: 'exam' },
      { date: 'Dec 20', event: 'Last Day of Fall Semester', type: 'academic' },
      { date: 'Dec 21 - Jan 8', event: 'Winter Break', type: 'break' }
    ],
    'Winter 2024': [
      { date: 'Jan 9', event: 'Spring Semester Begins', type: 'academic' },
      { date: 'Jan 15', event: 'Martin Luther King Jr. Day - No School', type: 'holiday' },
      { date: 'Feb 14', event: 'Valentine\'s Day Celebration', type: 'event' },
      { date: 'Feb 19', event: 'Presidents Day - No School', type: 'holiday' },
      { date: 'Mar 1', event: 'Science Fair', type: 'event' },
      { date: 'Mar 15', event: 'Mid-term Progress Reports', type: 'academic' },
      { date: 'Mar 25-29', event: 'Spring Break', type: 'break' }
    ],
    'Spring 2025': [
      { date: 'Apr 1', event: 'Classes Resume', type: 'academic' },
      { date: 'Apr 18', event: 'Good Friday - No School', type: 'holiday' },
      { date: 'May 1', event: 'Arts Festival', type: 'event' },
      { date: 'May 15', event: 'AP Exams Begin', type: 'exam' },
      { date: 'May 27', event: 'Memorial Day - No School', type: 'holiday' },
      { date: 'Jun 5', event: 'Final Exams Begin', type: 'exam' },
      { date: 'Jun 12', event: 'Graduation Ceremony', type: 'graduation' },
      { date: 'Jun 13', event: 'Last Day of School', type: 'academic' }
    ],
    'Summer 2025': [
      { date: 'Jun 16', event: 'Summer School Begins', type: 'academic' },
      { date: 'Jul 4', event: 'Independence Day - No School', type: 'holiday' },
      { date: 'Jul 15-19', event: 'Summer Camp Week 1', type: 'camp' },
      { date: 'Jul 22-26', event: 'Summer Camp Week 2', type: 'camp' },
      { date: 'Aug 1', event: 'Summer School Ends', type: 'academic' },
      { date: 'Aug 12-14', event: 'Teacher Professional Development', type: 'training' }
    ]
  };

  const getEventTypeColor = (type: string) => {
    const colors = {
      academic: 'bg-blue-100 text-blue-800 border-blue-200',
      holiday: 'bg-red-100 text-red-800 border-red-200',
      event: 'bg-green-100 text-green-800 border-green-200',
      meeting: 'bg-purple-100 text-purple-800 border-purple-200',
      break: 'bg-orange-100 text-orange-800 border-orange-200',
      exam: 'bg-yellow-100 text-yellow-800 border-yellow-200',
      graduation: 'bg-pink-100 text-pink-800 border-pink-200',
      camp: 'bg-teal-100 text-teal-800 border-teal-200',
      training: 'bg-indigo-100 text-indigo-800 border-indigo-200'
    };
    return colors[type as keyof typeof colors] || 'bg-gray-100 text-gray-800 border-gray-200';
  };

  const importantDates = [
    { title: 'Academic Year 2024-2025', date: 'August 19, 2024 - June 13, 2025' },
    { title: 'Fall Semester', date: 'August 19 - December 20, 2024' },
    { title: 'Spring Semester', date: 'January 9 - June 13, 2025' },
    { title: 'Summer School', date: 'June 16 - August 1, 2025' }
  ];

  return (
    <div className="min-h-screen bg-gray-50">
      <Header />
      
      <div className="relative bg-gradient-to-r from-blue-600 to-purple-600 text-white py-20">
        <div 
          className="absolute inset-0 bg-cover bg-center bg-no-repeat opacity-20"
          style={{
            backgroundImage: `url('https://readdy.ai/api/search-image?query=Modern%20school%20calendar%20with%20academic%20planning%2C%20students%20studying%20with%20schedules%20and%20planners%2C%20bright%20classroom%20environment%20with%20educational%20materials%2C%20clean%20organized%20academic%20setting%2C%20professional%20education%20atmosphere&width=1200&height=400&seq=school-calendar-hero&orientation=landscape')`
          }}
        ></div>
        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h1 className="text-5xl font-bold mb-6">School Calendar</h1>
          <p className="text-xl text-blue-100 max-w-3xl mx-auto">
            Stay informed about important dates, events, and academic milestones throughout the school year
          </p>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        {/* Important Dates Overview */}
        <div className="mb-12">
          <h2 className="text-3xl font-bold text-gray-900 mb-8">Important Dates 2024-2025</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {importantDates.map((item, index) => (
              <div key={index} className="bg-white rounded-xl shadow-lg p-6 border border-gray-100 hover:shadow-xl transition-shadow duration-300">
                <h3 className="font-semibold text-gray-900 mb-2">{item.title}</h3>
                <p className="text-blue-600 font-medium">{item.date}</p>
              </div>
            ))}
          </div>
        </div>

        {/* Term Selector */}
        <div className="mb-8">
          <div className="flex flex-wrap gap-2">
            {terms.map((term) => (
              <button
                key={term}
                onClick={() => setSelectedTerm(term)}
                className={`px-6 py-3 rounded-xl font-medium transition-all duration-200 whitespace-nowrap ${
                  selectedTerm === term
                    ? 'bg-blue-600 text-white shadow-lg'
                    : 'bg-white text-gray-700 hover:bg-blue-50 hover:text-blue-600 border border-gray-200'
                }`}
              >
                {term}
              </button>
            ))}
          </div>
        </div>

        {/* Calendar Events */}
        <div className="bg-white rounded-xl shadow-lg border border-gray-100">
          <div className="p-8">
            <h3 className="text-2xl font-bold text-gray-900 mb-6">{selectedTerm} Calendar</h3>
            <div className="space-y-4">
              {calendarEvents[selectedTerm as keyof typeof calendarEvents]?.map((event, index) => (
                <div key={index} className="flex items-center justify-between p-4 bg-gray-50 rounded-lg hover:bg-gray-100 transition-colors duration-200">
                  <div className="flex items-center space-x-4">
                    <div className="bg-blue-600 text-white rounded-lg px-3 py-2 font-semibold text-sm min-w-[80px] text-center">
                      {event.date}
                    </div>
                    <div>
                      <h4 className="font-semibold text-gray-900">{event.event}</h4>
                    </div>
                  </div>
                  <span className={`px-3 py-1 rounded-full text-xs font-medium border ${getEventTypeColor(event.type)}`}>
                    {event.type.charAt(0).toUpperCase() + event.type.slice(1)}
                  </span>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Additional Information */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mt-12">
          <div className="bg-white rounded-xl shadow-lg p-8 border border-gray-100">
            <h3 className="text-2xl font-bold text-gray-900 mb-6">Academic Schedule</h3>
            <div className="space-y-4">
              <div className="flex justify-between items-center py-3 border-b border-gray-100">
                <span className="font-medium text-gray-700">School Hours</span>
                <span className="text-gray-900">8:00 AM - 3:30 PM</span>
              </div>
              <div className="flex justify-between items-center py-3 border-b border-gray-100">
                <span className="font-medium text-gray-700">Extended Care</span>
                <span className="text-gray-900">7:00 AM - 6:00 PM</span>
              </div>
              <div className="flex justify-between items-center py-3 border-b border-gray-100">
                <span className="font-medium text-gray-700">Lunch Period</span>
                <span className="text-gray-900">12:00 PM - 1:00 PM</span>
              </div>
              <div className="flex justify-between items-center py-3">
                <span className="font-medium text-gray-700">Office Hours</span>
                <span className="text-gray-900">7:30 AM - 4:00 PM</span>
              </div>
            </div>
          </div>

          <div className="bg-white rounded-xl shadow-lg p-8 border border-gray-100">
            <h3 className="text-2xl font-bold text-gray-900 mb-6">Contact Information</h3>
            <div className="space-y-4">
              <div className="flex items-center space-x-3">
                <i className="ri-phone-line text-blue-600 w-5 h-5 flex items-center justify-center"></i>
                <div>
                  <p className="font-medium text-gray-900">Main Office</p>
                  <p className="text-gray-600">(555) 123-4567</p>
                </div>
              </div>
              <div className="flex items-center space-x-3">
                <i className="ri-mail-line text-blue-600 w-5 h-5 flex items-center justify-center"></i>
                <div>
                  <p className="font-medium text-gray-900">Email</p>
                  <p className="text-gray-600">calendar@vivekananda-school.edu</p>
                </div>
              </div>
              <div className="flex items-start space-x-3">
                <i className="ri-information-line text-blue-600 w-5 h-5 flex items-center justify-center mt-1"></i>
                <div>
                  <p className="font-medium text-gray-900">Updates</p>
                  <p className="text-gray-600 text-sm">Calendar changes will be communicated via email and school app notifications</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <Footer />
    </div>
  );
};

export default SchoolCalendar;
