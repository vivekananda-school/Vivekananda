'use client';

import Header from '../../../components/Header';
import Footer from '../../../components/Footer';

export default function FeeSchedule() {
  const feeStructure = [
    {
      grade: 'Kindergarten',
      tuition: 12500,
      registration: 500,
      materials: 300,
      technology: 200,
      activities: 250
    },
    {
      grade: 'Grades 1-3',
      tuition: 14500,
      registration: 500,
      materials: 400,
      technology: 250,
      activities: 300
    },
    {
      grade: 'Grades 4-6',
      tuition: 16500,
      registration: 500,
      materials: 500,
      technology: 300,
      activities: 350
    },
    {
      grade: 'Grades 7-9',
      tuition: 18500,
      registration: 500,
      materials: 600,
      technology: 400,
      activities: 400
    },
    {
      grade: 'Grades 10-12',
      tuition: 21500,
      registration: 500,
      materials: 700,
      technology: 500,
      activities: 450
    }
  ];

  const additionalFees = [
    { service: 'School Bus Transportation', fee: 1200, frequency: 'Annual' },
    { service: 'Lunch Program', fee: 800, frequency: 'Annual' },
    { service: 'After School Care (3:30-6:00 PM)', fee: 150, frequency: 'Monthly' },
    { service: 'Summer Camp Program', fee: 400, frequency: 'Per Week' },
    { service: 'Field Trip Activities', fee: 50, frequency: 'Per Trip' },
    { service: 'Music Lessons (Private)', fee: 120, frequency: 'Monthly' },
    { service: 'Sports Team Participation', fee: 200, frequency: 'Per Season' },
    { service: 'Uniform Package', fee: 300, frequency: 'One-time' }
  ];

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
      minimumFractionDigits: 0,
      maximumFractionDigits: 0,
    }).format(amount);
  };

  return (
    <div className="min-h-screen bg-white">
      <Header />

      {/* Hero Section */}
      <section className="relative py-24 overflow-hidden">
        <div 
          className="absolute inset-0 bg-cover bg-center bg-no-repeat"
          style={{
            backgroundImage: `url('https://readdy.ai/api/search-image?query=Professional%20school%20finance%20office%20with%20financial%20documents%20and%20calculator%20on%20modern%20desk%2C%20bright%20clean%20environment%20with%20educational%20materials%20and%20filing%20cabinets%2C%20warm%20lighting%20creating%20trustworthy%20atmosphere%20for%20tuition%20planning&width=1920&height=800&seq=fee-schedule-hero&orientation=landscape')`
          }}
        ></div>
        <div className="absolute inset-0 bg-gradient-to-br from-green-900/85 via-blue-800/75 to-purple-900/70"></div>
        
        <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center transform perspective-1000">
            <div className="bg-gradient-to-r from-white/15 to-white/10 backdrop-blur-lg rounded-3xl p-8 md:p-12 shadow-2xl border border-white/20 transform hover:scale-105 transition-all duration-700">
              <h1 className="text-4xl md:text-6xl font-bold text-white mb-6 leading-tight drop-shadow-2xl">
                <span className="bg-gradient-to-r from-yellow-300 via-green-300 to-blue-300 bg-clip-text text-transparent">Fee Schedule</span> 2024-2025
              </h1>
              <p className="text-xl md:text-2xl text-blue-100 mb-8 leading-relaxed drop-shadow-lg max-w-3xl mx-auto">
                Transparent pricing for quality education. Invest in your child's future with our comprehensive academic programs.
              </p>
            </div>
          </div>
        </div>

        {/* Floating Elements */}
        <div className="absolute top-20 left-10 w-32 h-32 bg-gradient-to-br from-green-400/20 to-blue-500/20 rounded-full blur-2xl animate-float"></div>
        <div className="absolute bottom-32 right-16 w-24 h-24 bg-gradient-to-br from-yellow-400/30 to-green-500/30 rounded-full blur-xl animate-float-delayed"></div>
      </section>

      {/* Main Fee Structure */}
      <section className="py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-gray-900 mb-6">Annual Tuition & Fees</h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Our fee structure is designed to provide exceptional value while maintaining the highest standards of education.
            </p>
          </div>

          <div className="bg-white rounded-3xl shadow-2xl overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead className="bg-gradient-to-r from-blue-600 to-purple-600">
                  <tr>
                    <th className="px-6 py-4 text-left text-sm font-semibold text-white">Grade Level</th>
                    <th className="px-6 py-4 text-right text-sm font-semibold text-white">Annual Tuition</th>
                    <th className="px-6 py-4 text-right text-sm font-semibold text-white">Registration</th>
                    <th className="px-6 py-4 text-right text-sm font-semibold text-white">Materials</th>
                    <th className="px-6 py-4 text-right text-sm font-semibold text-white">Technology</th>
                    <th className="px-6 py-4 text-right text-sm font-semibold text-white">Activities</th>
                    <th className="px-6 py-4 text-right text-sm font-semibold text-white">Total</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-gray-200">
                  {feeStructure.map((item, index) => {
                    const total = item.tuition + item.registration + item.materials + item.technology + item.activities;
                    return (
                      <tr key={index} className="hover:bg-gray-50 transition-colors duration-200">
                        <td className="px-6 py-4 font-semibold text-gray-900">{item.grade}</td>
                        <td className="px-6 py-4 text-right font-semibold text-blue-600">{formatCurrency(item.tuition)}</td>
                        <td className="px-6 py-4 text-right text-gray-600">{formatCurrency(item.registration)}</td>
                        <td className="px-6 py-4 text-right text-gray-600">{formatCurrency(item.materials)}</td>
                        <td className="px-6 py-4 text-right text-gray-600">{formatCurrency(item.technology)}</td>
                        <td className="px-6 py-4 text-right text-gray-600">{formatCurrency(item.activities)}</td>
                        <td className="px-6 py-4 text-right font-bold text-green-600 text-lg">{formatCurrency(total)}</td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </section>

      {/* Additional Fees */}
      <section className="py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-gray-900 mb-6">Additional Services & Fees</h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Optional services to enhance your child's educational experience.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {additionalFees.map((item, index) => (
              <div key={index} className="bg-white rounded-2xl shadow-xl p-6 transform hover:scale-105 transition-all duration-300">
                <div className="flex justify-between items-start mb-4">
                  <h3 className="text-lg font-semibold text-gray-900 flex-1">{item.service}</h3>
                  <div className="text-right">
                    <div className="text-2xl font-bold text-blue-600">{formatCurrency(item.fee)}</div>
                    <div className="text-sm text-gray-500">{item.frequency}</div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Payment Options */}
      <section className="py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
            <div className="bg-white rounded-3xl shadow-2xl p-8">
              <h3 className="text-2xl font-bold text-gray-900 mb-6 flex items-center">
                <i className="ri-credit-card-line text-blue-600 mr-3 w-7 h-7 flex items-center justify-center"></i>
                Payment Options
              </h3>
              
              <div className="space-y-6">
                <div className="flex items-start space-x-4">
                  <div className="w-12 h-12 bg-green-100 rounded-xl flex items-center justify-center">
                    <i className="ri-calendar-check-line text-green-600 w-6 h-6 flex items-center justify-center"></i>
                  </div>
                  <div>
                    <h4 className="font-semibold text-gray-900 mb-2">Annual Payment</h4>
                    <p className="text-gray-600 text-sm">Pay the full year upfront and receive a 5% discount on tuition fees.</p>
                  </div>
                </div>
                
                <div className="flex items-start space-x-4">
                  <div className="w-12 h-12 bg-blue-100 rounded-xl flex items-center justify-center">
                    <i className="ri-calendar-line text-blue-600 w-6 h-6 flex items-center justify-center"></i>
                  </div>
                  <div>
                    <h4 className="font-semibold text-gray-900 mb-2">Semester Payment</h4>
                    <p className="text-gray-600 text-sm">Split payments into two installments due at the beginning of each semester.</p>
                  </div>
                </div>
                
                <div className="flex items-start space-x-4">
                  <div className="w-12 h-12 bg-purple-100 rounded-xl flex items-center justify-center">
                    <i className="ri-calendar-2-line text-purple-600 w-6 h-6 flex items-center justify-center"></i>
                  </div>
                  <div>
                    <h4 className="font-semibold text-gray-900 mb-2">Monthly Payment Plan</h4>
                    <p className="text-gray-600 text-sm">Spread payments across 10 months with automatic bank transfers.</p>
                  </div>
                </div>
              </div>
            </div>

            <div className="bg-white rounded-3xl shadow-2xl p-8">
              <h3 className="text-2xl font-bold text-gray-900 mb-6 flex items-center">
                <i className="ri-hand-heart-line text-green-600 mr-3 w-7 h-7 flex items-center justify-center"></i>
                Financial Assistance
              </h3>
              
              <div className="space-y-6">
                <div className="p-6 bg-gradient-to-r from-blue-50 to-purple-50 rounded-2xl border border-blue-100">
                  <h4 className="font-semibold text-gray-900 mb-3">Merit-Based Scholarships</h4>
                  <p className="text-gray-600 text-sm mb-4">Up to 50% tuition reduction for students demonstrating exceptional academic achievement.</p>
                  <ul className="text-sm text-gray-600 space-y-1">
                    <li>• GPA requirement: 3.8 or higher</li>
                    <li>• Standardized test scores in top 10%</li>
                    <li>• Community service involvement</li>
                  </ul>
                </div>
                
                <div className="p-6 bg-gradient-to-r from-green-50 to-blue-50 rounded-2xl border border-green-100">
                  <h4 className="font-semibold text-gray-900 mb-3">Need-Based Aid</h4>
                  <p className="text-gray-600 text-sm mb-4">Financial assistance available for families based on demonstrated need.</p>
                  <ul className="text-sm text-gray-600 space-y-1">
                    <li>• Income-based assessment</li>
                    <li>• Up to 40% tuition assistance</li>
                    <li>• Confidential application process</li>
                  </ul>
                </div>
                
                <div className="p-6 bg-gradient-to-r from-yellow-50 to-orange-50 rounded-2xl border border-yellow-100">
                  <h4 className="font-semibold text-gray-900 mb-3">Sibling Discount</h4>
                  <p className="text-gray-600 text-sm">15% discount on tuition for second child, 25% for third child and beyond.</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Important Notes */}
      <section className="py-20">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="bg-white rounded-3xl shadow-2xl p-8">
            <h3 className="text-2xl font-bold text-gray-900 mb-6 flex items-center">
              <i className="ri-information-line text-blue-600 mr-3 w-7 h-7 flex items-center justify-center"></i>
              Important Information
            </h3>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              <div>
                <h4 className="font-semibold text-gray-900 mb-4">Fee Policy</h4>
                <ul className="space-y-2 text-sm text-gray-600">
                  <li className="flex items-start space-x-2">
                    <i className="ri-check-line text-green-600 mt-0.5 w-4 h-4 flex items-center justify-center flex-shrink-0"></i>
                    <span>Registration fee is non-refundable</span>
                  </li>
                  <li className="flex items-start space-x-2">
                    <i className="ri-check-line text-green-600 mt-0.5 w-4 h-4 flex items-center justify-center flex-shrink-0"></i>
                    <span>Late payment fee of $50 applies after 30 days</span>
                  </li>
                  <li className="flex items-start space-x-2">
                    <i className="ri-check-line text-green-600 mt-0.5 w-4 h-4 flex items-center justify-center flex-shrink-0"></i>
                    <span>Refund policy available upon request</span>
                  </li>
                  <li className="flex items-start space-x-2">
                    <i className="ri-check-line text-green-600 mt-0.5 w-4 h-4 flex items-center justify-center flex-shrink-0"></i>
                    <span>Fees subject to annual review</span>
                  </li>
                </ul>
              </div>
              
              <div>
                <h4 className="font-semibold text-gray-900 mb-4">Contact Information</h4>
                <div className="space-y-3 text-sm text-gray-600">
                  <div className="flex items-center space-x-3">
                    <i className="ri-phone-line text-blue-600 w-5 h-5 flex items-center justify-center"></i>
                    <span>Admissions: +1 (555) 123-4567</span>
                  </div>
                  <div className="flex items-center space-x-3">
                    <i className="ri-mail-line text-blue-600 w-5 h-5 flex items-center justify-center"></i>
                    <span>finance@vivekananda-school.edu</span>
                  </div>
                  <div className="flex items-center space-x-3">
                    <i className="ri-time-line text-blue-600 w-5 h-5 flex items-center justify-center"></i>
                    <span>Office Hours: Mon-Fri 8:00 AM - 4:00 PM</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      <Footer />
    </div>
  );
}