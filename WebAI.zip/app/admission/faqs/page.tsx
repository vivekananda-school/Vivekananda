'use client';

import { useState } from 'react';
import Header from '../../../components/Header';
import Footer from '../../../components/Footer';

export default function FAQs() {
  const [openFAQ, setOpenFAQ] = useState<number | null>(null);

  const toggleFAQ = (index: number) => {
    setOpenFAQ(openFAQ === index ? null : index);
  };

  const faqCategories = [
    {
      category: 'General Admission',
      faqs: [
        {
          question: 'What is the admission age requirement for different grades?',
          answer: 'Students must be 5 years old by September 1st for Kindergarten admission. For other grades, we assess students based on their academic readiness and previous school records. We accept students from ages 5-18 across all grade levels from Kindergarten through Grade 12.'
        },
        {
          question: 'What documents are required for admission?',
          answer: 'Required documents include: birth certificate, previous school transcripts and report cards, immunization records, completed application form, and a non-refundable application fee of $150. Additional documents may be requested based on specific circumstances.'
        },
        {
          question: 'When does the admission process begin each year?',
          answer: 'Applications for the following academic year open in October and continue through July. However, we encourage early applications as spaces fill quickly. Priority is given to applications received by March 1st for the best chance of securing admission.'
        },
        {
          question: 'Is there an entrance exam or assessment?',
          answer: 'Yes, all prospective students undergo an age-appropriate assessment to determine their academic level and ensure proper grade placement. This includes basic literacy and numeracy evaluations, and for older students, subject-specific assessments.'
        }
      ]
    },
    {
      category: 'Academic Programs',
      faqs: [
        {
          question: 'What curriculum do you follow?',
          answer: 'We follow an integrated curriculum combining the best elements of national standards with international best practices. Our program includes core subjects (Mathematics, English, Science, Social Studies), foreign languages (Spanish and French), arts, music, physical education, and technology integration.'
        },
        {
          question: 'What is your student-to-teacher ratio?',
          answer: 'We maintain small class sizes with a maximum student-to-teacher ratio of 15:1 in elementary grades and 18:1 in middle and high school. This ensures personalized attention and allows teachers to focus on each student\'s individual learning needs.'
        },
        {
          question: 'Do you offer Advanced Placement (AP) courses?',
          answer: 'Yes, we offer 12 AP courses including AP Calculus, AP Biology, AP Chemistry, AP Physics, AP English Literature, AP History, AP Computer Science, and AP Foreign Languages. Students typically begin taking AP courses in their junior year.'
        },
        {
          question: 'What support is available for students with learning differences?',
          answer: 'We have a dedicated Learning Support team that works with students who have documented learning differences. Our services include individualized education plans, extra time for assessments, alternative teaching methods, and regular progress monitoring.'
        }
      ]
    },
    {
      category: 'School Life & Activities',
      faqs: [
        {
          question: 'What extracurricular activities are available?',
          answer: 'We offer over 25 clubs and activities including Student Government, Debate Club, Science Club, Drama Club, Chess Club, Environmental Club, and various sports teams. We also have music ensembles, art clubs, and community service organizations.'
        },
        {
          question: 'What sports programs do you offer?',
          answer: 'Our athletics program includes soccer, basketball, volleyball, tennis, swimming, track and field, baseball, and softball. We have both competitive and recreational levels, and students can participate in multiple sports throughout the year.'
        },
        {
          question: 'Do you provide school transportation?',
          answer: 'Yes, we offer bus transportation covering a 15-mile radius around the school. The annual transportation fee is $1,200. Bus routes are established based on student enrollment and optimized for safety and efficiency.'
        },
        {
          question: 'What are your school hours?',
          answer: 'Regular school hours are 8:00 AM to 3:30 PM, Monday through Friday. We also offer before-school care starting at 7:00 AM and after-school care until 6:00 PM for an additional fee. Extended care includes supervised homework time and recreational activities.'
        }
      ]
    },
    {
      category: 'Fees & Financial Aid',
      faqs: [
        {
          question: 'Are there any hidden fees not mentioned in the fee schedule?',
          answer: 'No, our fee schedule is comprehensive and transparent. All mandatory fees are clearly listed including tuition, registration, materials, technology, and activities. Optional services like transportation, lunch program, and after-school care are separately listed with their respective costs.'
        },
        {
          question: 'What financial aid options are available?',
          answer: 'We offer merit-based scholarships up to 50% tuition reduction, need-based financial aid up to 40% tuition assistance, and sibling discounts (15% for second child, 25% for third child). We also have payment plans to spread costs over 10 months.'
        },
        {
          question: 'When are tuition payments due?',
          answer: 'Tuition can be paid annually (with 5% discount), semester-wise, or through a 10-month payment plan. Annual payments are due by July 1st, semester payments by July 1st and December 1st, and monthly payments are automatically debited from August through May.'
        },
        {
          question: 'What is your refund policy?',
          answer: 'Registration fees are non-refundable. Tuition refunds are prorated based on withdrawal date: 90% refund if withdrawn before school starts, 75% refund in first month, 50% refund in second month, and no refund after the second month of school.'
        }
      ]
    },
    {
      category: 'Health & Safety',
      faqs: [
        {
          question: 'What health and safety measures do you have in place?',
          answer: 'We have a full-time nurse on campus, secure building access with visitor management system, emergency response protocols, regular safety drills, and comprehensive health screening procedures. All staff undergo background checks and safety training.'
        },
        {
          question: 'What are your vaccination requirements?',
          answer: 'All students must provide up-to-date immunization records including MMR, DPT, Polio, Hepatitis B, and Varicella vaccines. Annual flu vaccines are strongly recommended. Medical exemptions require physician documentation.'
        },
        {
          question: 'How do you handle medical emergencies?',
          answer: 'Our school nurse is trained in first aid and CPR. For serious emergencies, we immediately contact 911 and parents. We maintain detailed medical records for all students and have protocols for managing chronic conditions like asthma and allergies.'
        },
        {
          question: 'What is your policy on medications?',
          answer: 'All medications must be stored in the health office with proper documentation from parents and physicians. Students are not allowed to carry medications except for emergency inhalers and EpiPens with proper authorization forms on file.'
        }
      ]
    }
  ];

  return (
    <div className="min-h-screen bg-white">
      <Header />

      {/* Hero Section */}
      <section className="relative py-24 overflow-hidden">
        <div 
          className="absolute inset-0 bg-cover bg-center bg-no-repeat"
          style={{
            backgroundImage: `url('https://readdy.ai/api/search-image?query=Friendly%20school%20counselor%20helping%20parents%20with%20questions%20in%20bright%20modern%20office%20setting%2C%20comfortable%20seating%20area%20with%20educational%20materials%20and%20helpful%20resources%2C%20warm%20professional%20atmosphere%20with%20natural%20lighting&width=1920&height=800&seq=faqs-hero&orientation=landscape')`
          }}
        ></div>
        <div className="absolute inset-0 bg-gradient-to-br from-purple-900/85 via-blue-800/75 to-green-900/70"></div>
        
        <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center transform perspective-1000">
            <div className="bg-gradient-to-r from-white/15 to-white/10 backdrop-blur-lg rounded-3xl p-8 md:p-12 shadow-2xl border border-white/20 transform hover:scale-105 transition-all duration-700">
              <h1 className="text-4xl md:text-6xl font-bold text-white mb-6 leading-tight drop-shadow-2xl">
                <span className="bg-gradient-to-r from-yellow-300 via-purple-300 to-green-300 bg-clip-text text-transparent">Frequently Asked</span> Questions
              </h1>
              <p className="text-xl md:text-2xl text-blue-100 mb-8 leading-relaxed drop-shadow-lg max-w-3xl mx-auto">
                Find answers to common questions about admission, academics, school life, and more.
              </p>
            </div>
          </div>
        </div>

        {/* Floating Elements */}
        <div className="absolute top-20 left-10 w-32 h-32 bg-gradient-to-br from-purple-400/20 to-green-500/20 rounded-full blur-2xl animate-float"></div>
        <div className="absolute bottom-32 right-16 w-24 h-24 bg-gradient-to-br from-yellow-400/30 to-purple-500/30 rounded-full blur-xl animate-float-delayed"></div>
      </section>

      {/* FAQ Categories */}
      <section className="py-20 bg-gray-50">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-gray-900 mb-6">Get Your Questions Answered</h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              We've compiled answers to the most common questions from parents and students. Can't find what you're looking for? Contact us directly.
            </p>
          </div>

          <div className="space-y-12">
            {faqCategories.map((category, categoryIndex) => (
              <div key={categoryIndex} className="bg-white rounded-3xl shadow-2xl overflow-hidden">
                <div className="bg-gradient-to-r from-blue-600 to-purple-600 px-8 py-6">
                  <h3 className="text-2xl font-bold text-white flex items-center">
                    <i className="ri-question-line mr-3 w-7 h-7 flex items-center justify-center"></i>
                    {category.category}
                  </h3>
                </div>
                
                <div className="p-8">
                  <div className="space-y-4">
                    {category.faqs.map((faq, faqIndex) => {
                      const globalIndex = categoryIndex * 10 + faqIndex;
                      return (
                        <div key={faqIndex} className="border border-gray-200 rounded-2xl overflow-hidden">
                          <button
                            onClick={() => toggleFAQ(globalIndex)}
                            className="w-full px-6 py-4 text-left bg-gray-50 hover:bg-gray-100 transition-colors duration-200 cursor-pointer"
                          >
                            <div className="flex justify-between items-center">
                              <h4 className="font-semibold text-gray-900 pr-4">{faq.question}</h4>
                              <i className={`w-6 h-6 flex items-center justify-center text-blue-600 transition-transform duration-200 ${
                                openFAQ === globalIndex ? 'ri-subtract-line rotate-180' : 'ri-add-line'
                              }`}></i>
                            </div>
                          </button>
                          
                          {openFAQ === globalIndex && (
                            <div className="px-6 py-4 bg-white border-t border-gray-200">
                              <p className="text-gray-600 leading-relaxed">{faq.answer}</p>
                            </div>
                          )}
                        </div>
                      );
                    })}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Contact Section */}
      <section className="py-20">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="bg-gradient-to-r from-blue-600 to-purple-600 rounded-3xl p-8 md:p-12 text-center">
            <h3 className="text-3xl font-bold text-white mb-6">Still Have Questions?</h3>
            <p className="text-xl text-blue-100 mb-8 max-w-2xl mx-auto">
              Our admissions team is here to help. Contact us for personalized assistance with your questions about Vivekananda International School.
            </p>
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
              <div className="bg-white/10 backdrop-blur-lg rounded-2xl p-6 border border-white/20">
                <i className="ri-phone-line text-white text-3xl mb-4 w-8 h-8 flex items-center justify-center mx-auto"></i>
                <h4 className="font-semibold text-white mb-2">Call Us</h4>
                <p className="text-blue-100">+1 (555) 123-4567</p>
              </div>
              
              <div className="bg-white/10 backdrop-blur-lg rounded-2xl p-6 border border-white/20">
                <i className="ri-mail-line text-white text-3xl mb-4 w-8 h-8 flex items-center justify-center mx-auto"></i>
                <h4 className="font-semibold text-white mb-2">Email Us</h4>
                <p className="text-blue-100">admissions@vivekananda-school.edu</p>
              </div>
              
              <div className="bg-white/10 backdrop-blur-lg rounded-2xl p-6 border border-white/20">
                <i className="ri-calendar-line text-white text-3xl mb-4 w-8 h-8 flex items-center justify-center mx-auto"></i>
                <h4 className="font-semibold text-white mb-2">Visit Us</h4>
                <p className="text-blue-100">Schedule a Campus Tour</p>
              </div>
            </div>
            
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <a
                href="/contact"
                className="bg-white text-blue-600 hover:bg-blue-50 px-8 py-4 rounded-2xl font-semibold transition-all duration-300 transform hover:scale-105 cursor-pointer whitespace-nowrap shadow-xl"
              >
                Contact Admissions Office
              </a>
              <a
                href="/admission/online-learning"
                className="bg-yellow-400 text-blue-900 hover:bg-yellow-300 px-8 py-4 rounded-2xl font-semibold transition-all duration-300 transform hover:scale-105 cursor-pointer whitespace-nowrap shadow-xl"
              >
                Apply Now
              </a>
            </div>
          </div>
        </div>
      </section>

      <Footer />
    </div>
  );
}