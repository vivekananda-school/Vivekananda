'use client';

import Header from '../../../components/Header';
import Footer from '../../../components/Footer';
import ApplicationForm from './ApplicationForm';
import AdmissionRequirements from './AdmissionRequirements';
import AdmissionProcess from './AdmissionProcess';

export default function OnlineLearning() {
  return (
    <div className="min-h-screen bg-white">
      <Header />

      {/* Hero Section */}
      <section className="relative py-24 overflow-hidden">
        <div 
          className="absolute inset-0 bg-cover bg-center bg-no-repeat"
          style={{
            backgroundImage: `url('https://readdy.ai/api/search-image?query=Modern%20school%20admission%20office%20with%20welcoming%20atmosphere%2C%20professional%20counselor%20helping%20parents%20and%20students%2C%20bright%20clean%20interior%20with%20educational%20materials%2C%20comfortable%20seating%20area%20with%20modern%20furniture%20and%20natural%20lighting&width=1920&height=800&seq=admission-hero&orientation=landscape')`
          }}
        ></div>
        <div className="absolute inset-0 bg-gradient-to-br from-blue-900/85 via-blue-800/75 to-purple-900/70"></div>
        
        <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center transform perspective-1000">
            <div className="bg-gradient-to-r from-white/15 to-white/10 backdrop-blur-lg rounded-3xl p-8 md:p-12 shadow-2xl border border-white/20 transform hover:scale-105 transition-all duration-700">
              <h1 className="text-4xl md:text-6xl font-bold text-white mb-6 leading-tight drop-shadow-2xl">
                <span className="bg-gradient-to-r from-yellow-300 via-blue-300 to-purple-300 bg-clip-text text-transparent">Apply Now</span> to Join Us
              </h1>
              <p className="text-xl md:text-2xl text-blue-100 mb-8 leading-relaxed drop-shadow-lg max-w-3xl mx-auto">
                Begin your child's journey towards excellence. Complete your application and become part of our vibrant learning community.
              </p>
            </div>
          </div>
        </div>

        {/* Floating Elements */}
        <div className="absolute top-20 left-10 w-32 h-32 bg-gradient-to-br from-blue-400/20 to-purple-500/20 rounded-full blur-2xl animate-float"></div>
        <div className="absolute bottom-32 right-16 w-24 h-24 bg-gradient-to-br from-yellow-400/30 to-orange-500/30 rounded-full blur-xl animate-float-delayed"></div>
      </section>

      {/* Application Form Section */}
      <section className="py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-12">
            <div className="lg:col-span-2">
              <ApplicationForm />
            </div>
            <div className="space-y-8">
              <AdmissionRequirements />
              <AdmissionProcess />
            </div>
          </div>
        </div>
      </section>

      <Footer />
    </div>
  );
}