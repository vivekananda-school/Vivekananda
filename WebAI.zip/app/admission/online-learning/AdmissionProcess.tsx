'use client';

const AdmissionProcess = () => {
  const processSteps = [
    {
      step: 1,
      title: 'Submit Application',
      description: 'Complete and submit the online application form with all required information.',
      icon: 'ri-file-text-line',
      color: 'bg-blue-500'
    },
    {
      step: 2,
      title: 'Document Review',
      description: 'Our admissions team reviews your application and supporting documents.',
      icon: 'ri-search-line',
      color: 'bg-green-500'
    },
    {
      step: 3,
      title: 'Assessment & Interview',
      description: 'Student assessment and family interview with our admissions counselor.',
      icon: 'ri-user-voice-line',
      color: 'bg-purple-500'
    },
    {
      step: 4,
      title: 'Admission Decision',
      description: 'Receive admission decision and enrollment information via email.',
      icon: 'ri-check-double-line',
      color: 'bg-orange-500'
    }
  ];

  return (
    <div className="bg-white rounded-3xl shadow-2xl p-8 transform hover:shadow-3xl transition-all duration-500">
      <h3 className="text-2xl font-bold text-gray-900 mb-6 flex items-center">
        <i className="ri-roadmap-line text-green-600 mr-3 w-7 h-7 flex items-center justify-center"></i>
        Admission Process
      </h3>
      
      <div className="space-y-6">
        {processSteps.map((step, index) => (
          <div key={step.step} className="relative">
            <div className="flex items-start space-x-4">
              <div className={`w-12 h-12 ${step.color} rounded-xl flex items-center justify-center flex-shrink-0 shadow-lg`}>
                <i className={`${step.icon} text-white text-lg w-6 h-6 flex items-center justify-center`}></i>
              </div>
              <div className="flex-1">
                <div className="flex items-center space-x-2 mb-2">
                  <span className="text-sm font-bold text-gray-500">STEP {step.step}</span>
                </div>
                <h4 className="font-semibold text-gray-900 text-lg mb-2">{step.title}</h4>
                <p className="text-gray-600 text-sm leading-relaxed">{step.description}</p>
              </div>
            </div>
            
            {index < processSteps.length - 1 && (
              <div className="absolute left-6 top-12 w-px h-8 bg-gray-200"></div>
            )}
          </div>
        ))}
      </div>
      
      <div className="mt-8 p-6 bg-gradient-to-r from-green-50 to-blue-50 rounded-2xl border border-green-100">
        <div className="flex items-start space-x-3">
          <i className="ri-time-line text-green-600 mt-1 w-6 h-6 flex items-center justify-center"></i>
          <div>
            <h4 className="font-semibold text-green-900 mb-2">Processing Timeline</h4>
            <p className="text-green-800 text-sm">
              The complete admission process typically takes 2-3 weeks from application submission to final decision. 
              We will keep you updated throughout the process via email and phone calls.
            </p>
          </div>
        </div>
      </div>
      
      <div className="mt-6 text-center">
        <div className="inline-flex items-center space-x-2 text-blue-600 font-medium">
          <i className="ri-phone-line w-5 h-5 flex items-center justify-center"></i>
          <span className="text-sm">Questions? Call us at +1 (555) 123-4567</span>
        </div>
      </div>
    </div>
  );
};

export default AdmissionProcess;