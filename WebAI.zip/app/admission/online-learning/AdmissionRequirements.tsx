'use client';

const AdmissionRequirements = () => {
  return (
    <div className="bg-white rounded-3xl shadow-2xl p-8 transform hover:shadow-3xl transition-all duration-500">
      <h3 className="text-2xl font-bold text-gray-900 mb-6 flex items-center">
        <i className="ri-file-list-line text-blue-600 mr-3 w-7 h-7 flex items-center justify-center"></i>
        Admission Requirements
      </h3>
      
      <div className="space-y-4">
        <div className="flex items-start space-x-3">
          <div className="w-6 h-6 bg-blue-100 rounded-full flex items-center justify-center mt-1">
            <i className="ri-check-line text-blue-600 text-sm w-4 h-4 flex items-center justify-center"></i>
          </div>
          <div>
            <h4 className="font-semibold text-gray-900">Birth Certificate</h4>
            <p className="text-gray-600 text-sm">Official copy of student's birth certificate</p>
          </div>
        </div>
        
        <div className="flex items-start space-x-3">
          <div className="w-6 h-6 bg-blue-100 rounded-full flex items-center justify-center mt-1">
            <i className="ri-check-line text-blue-600 text-sm w-4 h-4 flex items-center justify-center"></i>
          </div>
          <div>
            <h4 className="font-semibold text-gray-900">Previous School Records</h4>
            <p className="text-gray-600 text-sm">Transcripts and report cards from previous school</p>
          </div>
        </div>
        
        <div className="flex items-start space-x-3">
          <div className="w-6 h-6 bg-blue-100 rounded-full flex items-center justify-center mt-1">
            <i className="ri-check-line text-blue-600 text-sm w-4 h-4 flex items-center justify-center"></i>
          </div>
          <div>
            <h4 className="font-semibold text-gray-900">Immunization Records</h4>
            <p className="text-gray-600 text-sm">Up-to-date vaccination records</p>
          </div>
        </div>
        
        <div className="flex items-start space-x-3">
          <div className="w-6 h-6 bg-blue-100 rounded-full flex items-center justify-center mt-1">
            <i className="ri-check-line text-blue-600 text-sm w-4 h-4 flex items-center justify-center"></i>
          </div>
          <div>
            <h4 className="font-semibold text-gray-900">Application Fee</h4>
            <p className="text-gray-600 text-sm">Non-refundable application fee of $150</p>
          </div>
        </div>
        
        <div className="flex items-start space-x-3">
          <div className="w-6 h-6 bg-blue-100 rounded-full flex items-center justify-center mt-1">
            <i className="ri-check-line text-blue-600 text-sm w-4 h-4 flex items-center justify-center"></i>
          </div>
          <div>
            <h4 className="font-semibold text-gray-900">Entrance Assessment</h4>
            <p className="text-gray-600 text-sm">Age-appropriate evaluation for grade placement</p>
          </div>
        </div>
      </div>
      
      <div className="mt-8 p-4 bg-blue-50 rounded-xl border border-blue-100">
        <div className="flex items-start space-x-3">
          <i className="ri-information-line text-blue-600 mt-1 w-5 h-5 flex items-center justify-center"></i>
          <div>
            <h4 className="font-semibold text-blue-900">Important Note</h4>
            <p className="text-blue-800 text-sm">All documents must be submitted within 30 days of application submission. Incomplete applications will not be processed.</p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AdmissionRequirements;