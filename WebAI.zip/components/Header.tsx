
'use client';

import { useState, useRef, useEffect } from 'react';
import Link from 'next/link';

const Header = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [isAboutDropdownOpen, setIsAboutDropdownOpen] = useState(false);
  const [isAdmissionDropdownOpen, setIsAdmissionDropdownOpen] = useState(false);
  const [activeDropdown, setActiveDropdown] = useState<string | null>(null);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const dropdownTimeoutRef = useRef<NodeJS.Timeout | null>(null);

  const handleMouseEnter = (menu: string) => {
    if (dropdownTimeoutRef.current) {
      clearTimeout(dropdownTimeoutRef.current);
    }
    setActiveDropdown(menu);
  };

  const handleMouseLeave = () => {
    dropdownTimeoutRef.current = setTimeout(() => {
      setActiveDropdown(null);
    }, 100);
  };

  useEffect(() => {
    return () => {
      if (dropdownTimeoutRef.current) {
        clearTimeout(dropdownTimeoutRef.current);
      }
    };
  }, []);

  const navigationItems = [
    {
      title: 'About',
      items: [
        { name: 'Welcome', href: '/about/welcome' },
        { name: "Principal's Message", href: '/about/principal-message' },
        { name: 'Vision & Mission', href: '/about/vision-mission' },
        { name: 'School Profile', href: '/about/school-profile' }
      ]
    },
    {
      title: 'Admission',
      items: [
        { name: 'Online Learning', href: '/admission/online-learning' },
        { name: 'Fee Schedule', href: '/admission/fee-schedule' },
        { name: 'FAQs', href: '/admission/faqs' }
      ]
    },
    {
      title: 'Academics',
      items: [
        { name: 'School Calendar', href: '/academics/school-calendar' },
        { name: 'Curriculum (Syllabus)', href: '/academics/curriculum' },
        { name: 'Elective Courses', href: '/academics/elective-courses' }
      ]
    },
    {
      title: 'Student Life',
      items: [
        { name: 'Houses', href: '/student-life/houses' },
        { name: 'Community Service', href: '/student-life/community-service' },
        { name: 'CCA', href: '/student-life/cca' }
      ]
    }
  ];

  return (
    <header className="bg-white shadow-lg sticky top-0 z-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center py-4">
          <div className="flex items-center">
            <Link href="/" className="flex items-center space-x-3 cursor-pointer">
              <div className="w-12 h-12 bg-gradient-to-br from-blue-600 to-purple-600 rounded-xl flex items-center justify-center">
                <span className="text-white font-bold text-xl">V</span>
              </div>
              <div>
                <h1 className="text-2xl font-bold text-gray-900" style={{fontFamily: "Pacifico, serif"}}>logo</h1>
                <p className="text-sm text-gray-600">International School</p>
              </div>
            </Link>
          </div>

          <nav className="hidden lg:flex items-center space-x-8">
            <Link href="/" className="text-gray-700 hover:text-blue-600 transition-colors duration-200 cursor-pointer">
              Home
            </Link>

            <div className="relative group">
              <button 
                onClick={() => setIsAboutDropdownOpen(!isAboutDropdownOpen)}
                className="text-gray-700 hover:text-blue-600 transition-colors duration-200 flex items-center space-x-1 cursor-pointer"
              >
                <span>About</span>
                <i className={`ri-arrow-down-s-line transition-transform duration-200 w-4 h-4 flex items-center justify-center ${isAboutDropdownOpen ? 'rotate-180' : ''}`}></i>
              </button>

              {isAboutDropdownOpen && (
                <div className="absolute top-full left-0 mt-2 w-56 bg-white rounded-xl shadow-2xl border border-gray-100 py-2 z-50">
                  <Link href="/about/welcome" className="block px-4 py-3 text-gray-700 hover:text-blue-600 hover:bg-blue-50 transition-all duration-200 cursor-pointer">
                    Welcome
                  </Link>
                  <Link href="/about/principal-message" className="block px-4 py-3 text-gray-700 hover:text-blue-600 hover:bg-blue-50 transition-all duration-200 cursor-pointer">
                    Principal's Message
                  </Link>
                  <Link href="/about/vision-mission" className="block px-4 py-3 text-gray-700 hover:text-blue-600 hover:bg-blue-50 transition-all duration-200 cursor-pointer">
                    Vision & Mission
                  </Link>
                  <Link href="/about/school-profile" className="block px-4 py-3 text-gray-700 hover:text-blue-600 hover:bg-blue-50 transition-all duration-200 cursor-pointer">
                    School Profile
                  </Link>
                </div>
              )}
            </div>

            <div className="relative group">
              <button 
                onClick={() => setIsAdmissionDropdownOpen(!isAdmissionDropdownOpen)}
                className="text-gray-700 hover:text-blue-600 transition-colors duration-200 flex items-center space-x-1 cursor-pointer"
              >
                <span>Admission</span>
                <i className={`ri-arrow-down-s-line transition-transform duration-200 w-4 h-4 flex items-center justify-center ${isAdmissionDropdownOpen ? 'rotate-180' : ''}`}></i>
              </button>

              {isAdmissionDropdownOpen && (
                <div className="absolute top-full left-0 mt-2 w-56 bg-white rounded-xl shadow-2xl border border-gray-100 py-2 z-50">
                  <Link href="/admission/online-learning" className="block px-4 py-3 text-gray-700 hover:text-blue-600 hover:bg-blue-50 transition-all duration-200 cursor-pointer">
                    Online Learning
                  </Link>
                  <Link href="/admission/fee-schedule" className="block px-4 py-3 text-gray-700 hover:text-blue-600 hover:bg-blue-50 transition-all duration-200 cursor-pointer">
                    Fee Schedule
                  </Link>
                  <Link href="/admission/faqs" className="block px-4 py-3 text-gray-700 hover:text-blue-600 hover:bg-blue-50 transition-all duration-200 cursor-pointer">
                    FAQs
                  </Link>
                </div>
              )}
            </div>

            {navigationItems.slice(2).map((menu) => (
              <div
                key={menu.title}
                className="relative"
                onMouseEnter={() => handleMouseEnter(menu.title)}
                onMouseLeave={handleMouseLeave}
              >
                <button className="text-gray-700 hover:text-blue-600 font-medium transition-colors duration-200 flex items-center space-x-1 cursor-pointer whitespace-nowrap">
                  <span>{menu.title}</span>
                  <i className="ri-arrow-down-s-line w-4 h-4 flex items-center justify-center"></i>
                </button>

                {activeDropdown === menu.title && (
                  <div className="absolute top-full left-0 mt-2 w-64 bg-white rounded-lg shadow-xl border border-gray-100 py-2 transform opacity-100 scale-100 transition-all duration-200">
                    {menu.items.map((item) => (
                      <Link
                        key={item.name}
                        href={item.href}
                        className="block px-4 py-3 text-gray-700 hover:text-blue-600 hover:bg-blue-50 transition-all duration-200 cursor-pointer"
                      >
                        {item.name}
                      </Link>
                    ))}
                  </div>
                )}
              </div>
            ))}

            <Link href="/contact" className="text-gray-700 hover:text-blue-600 transition-colors duration-200 cursor-pointer">
              Contact Us
            </Link>
          </nav>

          <div className="hidden lg:flex items-center space-x-4">
            <Link 
              href="/admission/online-learning" 
              className="bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 text-white px-6 py-3 rounded-xl font-semibold transition-all duration-300 transform hover:scale-105 cursor-pointer whitespace-nowrap shadow-lg"
            >
              Apply Now
            </Link>
          </div>

          <div className="lg:hidden">
            <button
              onClick={() => setIsMenuOpen(!isMenuOpen)}
              className="text-gray-700 hover:text-blue-600 cursor-pointer"
            >
              <i className={`${isMenuOpen ? 'ri-close-line' : 'ri-menu-line'} text-2xl w-6 h-6 flex items-center justify-center`}></i>
            </button>
          </div>
        </div>

        {isMenuOpen && (
          <div className="lg:hidden">
            <div className="px-2 pt-2 pb-3 space-y-1 border-t border-gray-200">
              <Link href="/" className="block px-3 py-2 text-gray-700 hover:text-blue-600 transition-colors duration-200 cursor-pointer">
                Home
              </Link>
              <div className="px-3 py-2">
                <div className="font-semibold text-gray-900 mb-2">About</div>
                <div className="pl-4 space-y-1">
                  <Link href="/about/welcome" className="block py-1 text-gray-600 hover:text-blue-600 cursor-pointer">
                    Welcome
                  </Link>
                  <Link href="/about/principal-message" className="block py-1 text-gray-600 hover:text-blue-600 cursor-pointer">
                    Principal's Message
                  </Link>
                  <Link href="/about/vision-mission" className="block py-1 text-gray-600 hover:text-blue-600 cursor-pointer">
                    Vision & Mission
                  </Link>
                  <Link href="/about/school-profile" className="block py-1 text-gray-600 hover:text-blue-600 cursor-pointer">
                    School Profile
                  </Link>
                </div>
              </div>
              <div className="px-3 py-2">
                <div className="font-semibold text-gray-900 mb-2">Admission</div>
                <div className="pl-4 space-y-1">
                  <Link href="/admission/online-learning" className="block py-1 text-gray-600 hover:text-blue-600 cursor-pointer">
                    Online Learning
                  </Link>
                  <Link href="/admission/fee-schedule" className="block py-1 text-gray-600 hover:text-blue-600 cursor-pointer">
                    Fee Schedule
                  </Link>
                  <Link href="/admission/faqs" className="block py-1 text-gray-600 hover:text-blue-600 cursor-pointer">
                    FAQs
                  </Link>
                </div>
              </div>
              {navigationItems.slice(2).map((menu) => (
                <div key={menu.title} className="space-y-1">
                  <div className="px-3 py-2 text-gray-900 font-medium border-b border-gray-100">
                    {menu.title}
                  </div>
                  {menu.items.map((item) => (
                    <Link
                      key={item.name}
                      href={item.href}
                      className="block px-6 py-2 text-gray-600 hover:text-blue-600 hover:bg-blue-50 rounded-md transition-colors duration-200 cursor-pointer"
                      onClick={() => setIsMobileMenuOpen(false)}
                    >
                      {item.name}
                    </Link>
                  ))}
                </div>
              ))}
              <Link href="/contact" className="block px-3 py-2 text-gray-700 hover:text-blue-600 transition-colors duration-200 cursor-pointer">
                Contact Us
              </Link>
              <div className="px-3 py-2">
                <Link 
                  href="/admission/online-learning" 
                  className="block w-full text-center bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 text-white px-6 py-3 rounded-xl font-semibold transition-all duration-300 cursor-pointer whitespace-nowrap"
                >
                  Apply Now
                </Link>
              </div>
            </div>
          </div>
        )}
      </div>
    </header>
  );
};

export default Header;
