'use client';

import Link from 'next/link';

const Footer = () => {
  return (
    <footer className="bg-gray-900 text-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {/* School Info */}
          <div className="space-y-4">
            <div className="flex items-center space-x-2">
              <div className="w-8 h-8 bg-blue-600 rounded-lg flex items-center justify-center">
                <i className="ri-graduation-cap-line text-white w-5 h-5 flex items-center justify-center"></i>
              </div>
              <div>
                <h3 className="font-bold">Vivekananda</h3>
                <p className="text-xs text-gray-400">International School</p>
              </div>
            </div>
            <p className="text-gray-300 text-sm">
              Nurturing young minds with excellence in education and character development since 1985.
            </p>
            <div className="flex space-x-4">
              <a href="#" className="text-gray-400 hover:text-blue-400 transition-colors duration-200 cursor-pointer">
                <i className="ri-facebook-line w-5 h-5 flex items-center justify-center"></i>
              </a>
              <a href="#" className="text-gray-400 hover:text-blue-400 transition-colors duration-200 cursor-pointer">
                <i className="ri-twitter-line w-5 h-5 flex items-center justify-center"></i>
              </a>
              <a href="#" className="text-gray-400 hover:text-blue-400 transition-colors duration-200 cursor-pointer">
                <i className="ri-instagram-line w-5 h-5 flex items-center justify-center"></i>
              </a>
              <a href="#" className="text-gray-400 hover:text-blue-400 transition-colors duration-200 cursor-pointer">
                <i className="ri-youtube-line w-5 h-5 flex items-center justify-center"></i>
              </a>
            </div>
          </div>

          {/* Quick Links */}
          <div className="space-y-4">
            <h4 className="font-semibold text-lg">Quick Links</h4>
            <ul className="space-y-2">
              <li><Link href="/about/welcome" className="text-gray-300 hover:text-blue-400 transition-colors duration-200 cursor-pointer">About Us</Link></li>
              <li><Link href="/admission/online-learning" className="text-gray-300 hover:text-blue-400 transition-colors duration-200 cursor-pointer">Admissions</Link></li>
              <li><Link href="/academics/curriculum" className="text-gray-300 hover:text-blue-400 transition-colors duration-200 cursor-pointer">Academics</Link></li>
              <li><Link href="/student-life/houses" className="text-gray-300 hover:text-blue-400 transition-colors duration-200 cursor-pointer">Student Life</Link></li>
            </ul>
          </div>

          {/* Contact Info */}
          <div className="space-y-4">
            <h4 className="font-semibold text-lg">Contact Info</h4>
            <div className="space-y-3">
              <div className="flex items-start space-x-3">
                <i className="ri-map-pin-line text-blue-400 mt-1 w-5 h-5 flex items-center justify-center"></i>
                <p className="text-gray-300 text-sm">123 Education Street, Knowledge City, KC 12345</p>
              </div>
              <div className="flex items-center space-x-3">
                <i className="ri-phone-line text-blue-400 w-5 h-5 flex items-center justify-center"></i>
                <p className="text-gray-300 text-sm">+1 (555) 123-4567</p>
              </div>
              <div className="flex items-center space-x-3">
                <i className="ri-mail-line text-blue-400 w-5 h-5 flex items-center justify-center"></i>
                <p className="text-gray-300 text-sm">info@vivekananda-school.edu</p>
              </div>
            </div>
          </div>

          {/* Newsletter */}
          <div className="space-y-4">
            <h4 className="font-semibold text-lg">Stay Updated</h4>
            <p className="text-gray-300 text-sm">Subscribe to our newsletter for latest updates and announcements.</p>
            <div className="space-y-2">
              <input
                type="email"
                placeholder="Your email address"
                className="w-full px-3 py-2 bg-gray-800 border border-gray-700 rounded-lg text-white placeholder-gray-400 focus:outline-none focus:border-blue-500 transition-colors duration-200 text-sm"
              />
              <button className="w-full bg-blue-600 hover:bg-blue-700 text-white py-2 px-4 rounded-lg transition-colors duration-200 font-medium text-sm cursor-pointer whitespace-nowrap">
                Subscribe
              </button>
            </div>
          </div>
        </div>

        <div className="border-t border-gray-800 mt-8 pt-8 flex flex-col sm:flex-row justify-between items-center">
          <p className="text-gray-400 text-sm">© 2024 Vivekananda International School. All rights reserved.</p>
          <div className="flex space-x-6 mt-4 sm:mt-0">
            <Link href="/privacy" className="text-gray-400 hover:text-blue-400 text-sm transition-colors duration-200 cursor-pointer">Privacy Policy</Link>
            <Link href="/terms" className="text-gray-400 hover:text-blue-400 text-sm transition-colors duration-200 cursor-pointer">Terms of Service</Link>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;